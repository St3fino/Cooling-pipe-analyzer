"""Module-wide configuration constants for Hydronet."""
from __future__ import annotations

#: Gravitational acceleration (m/s^2)
G_ACCEL: float = 9.80665

#: Default reference temperature (K) when none is provided
T_REF_K: float = 293.15

#: Default fluid name
DEFAULT_FLUID: str = "Water"

#: Convergence tolerance for flow-based solvers (m^3/s)
Q_ABS_TOL: float = 1.0e-9

#: Convergence tolerance for pressure-based solvers (Pa)
DP_ABS_TOL: float = 1.0e-3

#: Maximum bracket-expansion iterations for inverse hydraulic curves
MAX_BRACKET_EXPAND: int = 60

#: Initial bracket size for Q (m^3/s) used by inverse curve search
Q_HI_HINT_INIT: float = 1.0e-3

#: Floor used when Re ≈ 0 to keep Churchill correlation numerically stable
RE_MIN: float = 1.0e-6
