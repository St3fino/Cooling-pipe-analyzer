"""Serialize and deserialize a Hydronet project to/from JSON."""
from __future__ import annotations

import json
from typing import Any, Optional

from hydronet.domain.elements import (
    CurveComponentElement,
    Element,
    MinorLossElement,
    PipeElement,
    PumpElement,
)
from hydronet.domain.fluid import FluidState, get_fluid_state
from hydronet.domain.network import Node, TreeNetwork

PROJECT_SCHEMA_VERSION = "1.0"


def save_project(network: TreeNetwork, fluid: FluidState,
                 metadata: Optional[dict] = None) -> str:
    """Return a JSON string for the project."""
    payload: dict[str, Any] = {
        "schema": PROJECT_SCHEMA_VERSION,
        "metadata": dict(metadata or {}),
        "fluid": fluid.model_dump(),
        "network": {
            "root_id": network.root_id,
            "nodes": [
                {"id": n.id, "name": n.name, "kind": n.kind, "p_fixed": n.p_fixed}
                for n in network.nodes.values()
            ],
            "elements": [el.describe() for el in network.elements.values()],
        },
    }
    return json.dumps(payload, indent=2)


def load_project(payload: str) -> tuple[TreeNetwork, FluidState]:
    """Inverse of :func:`save_project`. Raises ValueError on schema mismatch."""
    data = json.loads(payload)
    schema = data.get("schema")
    if schema != PROJECT_SCHEMA_VERSION:
        raise ValueError(
            f"Unsupported project schema {schema!r}; expected {PROJECT_SCHEMA_VERSION!r}"
        )
    fluid_d = data["fluid"]
    fluid = FluidState(**fluid_d)

    network = TreeNetwork()
    for nd in data["network"]["nodes"]:
        network.add_node(Node(
            id=nd["id"], name=nd["name"], kind=nd["kind"], p_fixed=nd.get("p_fixed"),
        ))
    for ed in data["network"]["elements"]:
        network.add_element(_element_from_dict(ed))
    return network, fluid


# ---------------------------------------------------------------------------
def _element_from_dict(d: dict) -> Element:
    t = d["type"]
    common = dict(
        id=d["id"], name=d["name"],
        from_node=d["from_node"], to_node=d["to_node"],
        enabled=d.get("enabled", True),
    )
    if t == "Pipe":
        return PipeElement(
            **common,
            L_m=d["L_m"], D_m=d["D_m"],
            material=d.get("material", "SteelCommercial"),
            eps_m=d.get("eps_m"),
        )
    if t == "MinorLoss":
        return MinorLossElement(
            **common,
            fitting_type=d["fitting_type"],
            D_ref_m=d["D_ref_m"],
            K_override=d.get("K"),
        )
    if t == "CurveComponent":
        return CurveComponentElement(
            **common,
            Q_points=d.get("Q_points"),
            dp_points=d.get("dp_points"),
            poly_coeffs=d.get("poly_coeffs"),
        )
    if t == "Pump":
        return PumpElement(
            **common,
            Q_points=d.get("Q_points"),
            dp_rise_points=d.get("dp_rise_points"),
            H_points=d.get("H_points"),
            poly_coeffs=d.get("poly_coeffs"),
        )
    raise ValueError(f"Unknown element type {t!r}")
