"""CSV export utilities.

Flatten a :class:`SimulationResult` into pandas DataFrames suitable for the UI
and for export to disk.
"""
from __future__ import annotations

from pathlib import Path
from typing import Union

import pandas as pd

from hydronet.solver.tree_solver import SimulationResult

PathLike = Union[str, Path]


# ---------------------------------------------------------------------------
# DataFrame builders
# ---------------------------------------------------------------------------
_ELEMENT_COLUMNS: list[str] = [
    "element_id", "type", "Q", "dp",
    "v", "Re", "f", "K",
    "L", "D", "eps",
    "dp_major", "dp_minor", "dp_rise",
    "notes",
]

_BRANCH_COLUMNS: list[str] = [
    "branch_id", "Q", "dp_total", "element_ids",
]


def elements_dataframe(result: SimulationResult) -> pd.DataFrame:
    """Return a DataFrame with one row per element in ``result``.

    Columns are stable and ordered: ``element_id, type, Q, dp, v, Re, f, K,
    L, D, eps, dp_major, dp_minor, dp_rise, notes``. Missing values are left
    as NaN so the caller can format / fill as desired.
    """
    rows: list[dict] = [er.model_dump() for er in result.elements]
    if not rows:
        return pd.DataFrame(columns=_ELEMENT_COLUMNS)
    df = pd.DataFrame(rows)
    # Re-order, adding any missing columns as NaN
    for col in _ELEMENT_COLUMNS:
        if col not in df.columns:
            df[col] = pd.NA
    return df[_ELEMENT_COLUMNS]


def branches_dataframe(result: SimulationResult) -> pd.DataFrame:
    """Return a DataFrame with one row per root→leaf branch."""
    rows: list[dict] = []
    for br in result.branches:
        d = br.model_dump()
        # element_ids → comma-joined string for CSV friendliness
        d["element_ids"] = ", ".join(d.get("element_ids", []) or [])
        rows.append(d)
    if not rows:
        return pd.DataFrame(columns=_BRANCH_COLUMNS)
    df = pd.DataFrame(rows)
    for col in _BRANCH_COLUMNS:
        if col not in df.columns:
            df[col] = pd.NA
    return df[_BRANCH_COLUMNS]


# ---------------------------------------------------------------------------
# Disk writers
# ---------------------------------------------------------------------------
def write_elements_csv(result: SimulationResult, path: PathLike) -> None:
    """Write the per-element diagnostics table to ``path`` as CSV."""
    df = elements_dataframe(result)
    df.to_csv(path, index=False)


def write_branches_csv(result: SimulationResult, path: PathLike) -> None:
    """Write the per-branch summary table to ``path`` as CSV."""
    df = branches_dataframe(result)
    df.to_csv(path, index=False)


__all__ = [
    "elements_dataframe",
    "branches_dataframe",
    "write_elements_csv",
    "write_branches_csv",
]
