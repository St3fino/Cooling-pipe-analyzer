"""Tree network data structure.

A :class:`TreeNetwork` is a directed acyclic graph in which every node has
exactly one parent element (incoming) except the root, which has none.
Elements carry the physical model; the network only encodes topology.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Iterable, Literal, Optional

if TYPE_CHECKING:  # avoid circular import at runtime
    from hydronet.domain.elements.base import Element

NodeKind = Literal["root", "junction", "leaf"]


@dataclass
class Node:
    """A single node in the network.

    ``p_fixed`` is the absolute pressure (Pa) prescribed at the node when it
    serves as a boundary (root or leaf). ``None`` means the pressure is
    determined by the solve.
    """

    id: str
    name: str
    kind: NodeKind = "junction"
    p_fixed: Optional[float] = None


class NetworkError(ValueError):
    """Topology / consistency error in a :class:`TreeNetwork`."""


@dataclass
class TreeNetwork:
    """Directed tree of nodes and elements.

    Construct nodes and elements with :meth:`add_node` / :meth:`add_element`
    rather than mutating the dictionaries directly.  Run :meth:`validate_tree`
    before passing the network to a solver.
    """

    nodes: dict[str, Node] = field(default_factory=dict)
    elements: dict[str, "Element"] = field(default_factory=dict)
    children: dict[str, list[str]] = field(default_factory=dict)
    parent_map: dict[str, str] = field(default_factory=dict)
    root_id: Optional[str] = None

    # ------------------------------------------------------------------
    # Construction
    # ------------------------------------------------------------------
    def add_node(self, node: Node) -> Node:
        if node.id in self.nodes:
            raise NetworkError(f"Duplicate node id: {node.id!r}")
        self.nodes[node.id] = node
        self.children.setdefault(node.id, [])
        if node.kind == "root":
            if self.root_id is not None and self.root_id != node.id:
                raise NetworkError(
                    f"Network already has root {self.root_id!r}; "
                    f"cannot add another root {node.id!r}"
                )
            self.root_id = node.id
        return node

    def add_element(self, element: "Element") -> "Element":
        if element.id in self.elements:
            raise NetworkError(f"Duplicate element id: {element.id!r}")
        if element.from_node not in self.nodes:
            raise NetworkError(f"Unknown from_node {element.from_node!r}")
        if element.to_node not in self.nodes:
            raise NetworkError(f"Unknown to_node {element.to_node!r}")
        if element.from_node == element.to_node:
            raise NetworkError(
                f"Self-loop forbidden: element {element.id!r} connects "
                f"{element.from_node!r} to itself"
            )
        if element.to_node in self.parent_map:
            raise NetworkError(
                f"Node {element.to_node!r} already has parent "
                f"{self.parent_map[element.to_node]!r}; adding {element.id!r} would "
                "create a cycle or multi-parent topology (forbidden in MVP TREE network)."
            )
        # Cycle pre-check: from_node must not be a descendant of to_node
        if self._is_descendant(ancestor=element.to_node, candidate=element.from_node):
            raise NetworkError(
                f"Adding element {element.id!r} from {element.from_node!r} to "
                f"{element.to_node!r} would close a cycle. Tree networks only."
            )
        self.elements[element.id] = element
        self.children.setdefault(element.from_node, []).append(element.id)
        self.parent_map[element.to_node] = element.id
        return element

    # ------------------------------------------------------------------
    # Validation
    # ------------------------------------------------------------------
    def validate_tree(self) -> None:
        """Raise :class:`NetworkError` if the network is not a valid tree."""
        if self.root_id is None:
            raise NetworkError("Network has no root node.")
        roots = [n.id for n in self.nodes.values() if n.kind == "root"]
        if len(roots) != 1:
            raise NetworkError(f"Exactly one root expected, found {len(roots)}: {roots}")
        # Every non-root must have exactly one parent element.
        for nid, node in self.nodes.items():
            if nid == self.root_id:
                if nid in self.parent_map:
                    raise NetworkError(f"Root {nid!r} unexpectedly has a parent.")
            else:
                if nid not in self.parent_map:
                    raise NetworkError(f"Node {nid!r} has no parent element.")
        # Reachability and acyclicity: a depth-first walk from root must reach every node
        # exactly once.
        seen: set[str] = set()
        stack = [self.root_id]
        while stack:
            nid = stack.pop()
            if nid in seen:
                raise NetworkError(f"Cycle or duplicate path detected at node {nid!r}.")
            seen.add(nid)
            for eid in self.children.get(nid, []):
                stack.append(self.elements[eid].to_node)
        if seen != set(self.nodes):
            unreachable = set(self.nodes) - seen
            raise NetworkError(f"Nodes not reachable from root: {sorted(unreachable)}")

    # ------------------------------------------------------------------
    # Traversal helpers
    # ------------------------------------------------------------------
    def post_order_nodes(self) -> list[str]:
        """Post-order DFS — children first, then parent. Useful for reduction."""
        order: list[str] = []
        visited: set[str] = set()

        def dfs(nid: str) -> None:
            visited.add(nid)
            for eid in self.children.get(nid, []):
                child = self.elements[eid].to_node
                if child not in visited:
                    dfs(child)
            order.append(nid)

        if self.root_id is not None:
            dfs(self.root_id)
        return order

    def pre_order_nodes(self) -> list[str]:
        """Pre-order DFS — parent first, then children. Useful for reconstruction."""
        order: list[str] = []
        if self.root_id is None:
            return order
        stack = [self.root_id]
        seen: set[str] = set()
        while stack:
            nid = stack.pop()
            if nid in seen:
                continue
            seen.add(nid)
            order.append(nid)
            for eid in self.children.get(nid, []):
                stack.append(self.elements[eid].to_node)
        return order

    def leaves(self) -> list[str]:
        """Return ids of all leaf nodes (nodes with no children)."""
        return [nid for nid in self.nodes if not self.children.get(nid)]

    def path_from_root_to(self, nid: str) -> list[str]:
        """Return the chain of element ids from root to ``nid`` (empty for root)."""
        if nid == self.root_id:
            return []
        chain: list[str] = []
        cur = nid
        while cur != self.root_id:
            eid = self.parent_map[cur]
            chain.append(eid)
            cur = self.elements[eid].from_node
        chain.reverse()
        return chain

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------
    def _is_descendant(self, *, ancestor: str, candidate: str) -> bool:
        """Whether ``candidate`` is in the subtree rooted at ``ancestor``."""
        stack: list[str] = [ancestor]
        seen: set[str] = set()
        while stack:
            nid = stack.pop()
            if nid in seen:
                continue
            seen.add(nid)
            if nid == candidate:
                return True
            for eid in self.children.get(nid, []):
                stack.append(self.elements[eid].to_node)
        return False

    # ------------------------------------------------------------------
    # Convenience
    # ------------------------------------------------------------------
    def summary(self) -> dict:
        return {
            "num_nodes": len(self.nodes),
            "num_elements": len(self.elements),
            "root_id": self.root_id,
            "leaves": self.leaves(),
        }
