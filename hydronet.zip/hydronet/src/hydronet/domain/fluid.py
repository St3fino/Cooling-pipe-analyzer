"""Fluid property providers.

Exposes a :class:`FluidState` and two providers:

* :class:`CoolPropProvider` — uses CoolProp when available.
* :class:`FallbackProvider` — built-in approximations for ``Water`` and
  ``WaterGlycol50`` (50 % glycol by mass; constant ρ, μ over typical
  industrial temperatures — explicitly documented below).

A module-level helper :func:`get_fluid_state` selects the best available
provider and returns a frozen :class:`FluidState`.
"""
from __future__ import annotations

from functools import lru_cache
from typing import Protocol, Tuple

from pydantic import BaseModel, Field

from hydronet.utils.logging import get_logger

_logger = get_logger(__name__)


# ---------------------------------------------------------------------------
# FluidState
# ---------------------------------------------------------------------------
class FluidState(BaseModel):
    """Immutable snapshot of fluid properties at a single operating point."""

    fluid_name: str = Field(..., description="Identifier of the fluid")
    T_K: float = Field(..., gt=0.0, description="Temperature in Kelvin")
    rho: float = Field(..., gt=0.0, description="Density (kg/m^3)")
    mu: float = Field(..., gt=0.0, description="Dynamic viscosity (Pa·s)")

    model_config = {"frozen": True}

    @property
    def T_C(self) -> float:
        """Temperature in Celsius."""
        return self.T_K - 273.15

    @property
    def nu(self) -> float:
        """Kinematic viscosity (m^2/s)."""
        return self.mu / self.rho


# ---------------------------------------------------------------------------
# Provider protocol
# ---------------------------------------------------------------------------
class PropsProvider(Protocol):
    """Anything that can return (rho, mu) for a fluid name + temperature (K)."""

    def get_rho_mu(self, fluid_name: str, T_K: float) -> Tuple[float, float]:  # noqa: D401
        ...

    @property
    def name(self) -> str:
        ...


# ---------------------------------------------------------------------------
# CoolProp provider (optional)
# ---------------------------------------------------------------------------
try:  # pragma: no cover - import guard
    from CoolProp.CoolProp import PropsSI as _PropsSI  # type: ignore
    _HAS_COOLPROP = True
except Exception:  # ImportError, OSError, etc.
    _PropsSI = None  # type: ignore[assignment]
    _HAS_COOLPROP = False


# Map our fluid names to CoolProp identifiers
_COOLPROP_NAME_MAP = {
    "Water": "Water",
    # 50% mass glycol -> incompressible mixture in CoolProp
    "WaterGlycol50": "INCOMP::MEG[0.50]",
}


class CoolPropProvider:
    """CoolProp-backed provider. Raises if CoolProp is unavailable."""

    name = "CoolProp"

    def __init__(self) -> None:
        if not _HAS_COOLPROP:
            raise RuntimeError("CoolProp is not installed.")

    def get_rho_mu(self, fluid_name: str, T_K: float) -> Tuple[float, float]:
        cp_name = _COOLPROP_NAME_MAP.get(fluid_name)
        if cp_name is None:
            raise ValueError(f"CoolProp mapping unknown for fluid {fluid_name!r}")
        # Use atmospheric reference pressure for incompressible liquids
        p_ref = 101325.0
        rho = float(_PropsSI("D", "T", T_K, "P", p_ref, cp_name))  # type: ignore[misc]
        mu = float(_PropsSI("V", "T", T_K, "P", p_ref, cp_name))  # type: ignore[misc]
        return rho, mu


# ---------------------------------------------------------------------------
# Fallback provider
# ---------------------------------------------------------------------------
def _water_rho(T_K: float) -> float:
    """Simple ρ_water(T) approximation, valid roughly 273–373 K.

    Linear fit through standard values:
        273 K -> 999.8     293 K -> 998.2     333 K -> 983.2     363 K -> 965.3
    A piecewise-linear interpolant is adequate for engineering MVP work.
    """
    pts = [(273.15, 999.8), (293.15, 998.2), (313.15, 992.2),
           (333.15, 983.2), (353.15, 971.8), (373.15, 958.4)]
    if T_K <= pts[0][0]:
        return pts[0][1]
    if T_K >= pts[-1][0]:
        return pts[-1][1]
    for (t0, v0), (t1, v1) in zip(pts, pts[1:]):
        if t0 <= T_K <= t1:
            f = (T_K - t0) / (t1 - t0)
            return v0 + f * (v1 - v0)
    return pts[-1][1]


def _water_mu(T_K: float) -> float:
    """Simple μ_water(T) approximation (Pa·s), valid roughly 273–373 K."""
    pts = [(273.15, 1.792e-3), (293.15, 1.002e-3), (313.15, 6.53e-4),
           (333.15, 4.66e-4), (353.15, 3.55e-4), (373.15, 2.82e-4)]
    if T_K <= pts[0][0]:
        return pts[0][1]
    if T_K >= pts[-1][0]:
        return pts[-1][1]
    for (t0, v0), (t1, v1) in zip(pts, pts[1:]):
        if t0 <= T_K <= t1:
            f = (T_K - t0) / (t1 - t0)
            return v0 + f * (v1 - v0)
    return pts[-1][1]


def _glycol50_rho(T_K: float) -> float:
    """ρ for 50 wt-% ethylene-glycol / water mixture.

    Constant approximation for MVP: 1067 kg/m^3 (≈ value at 293 K). Documented
    limitation; install CoolProp for proper temperature dependence.
    """
    return 1067.0


def _glycol50_mu(T_K: float) -> float:
    """μ for 50 wt-% ethylene-glycol / water mixture.

    Mild temperature dependence approximated by piecewise-linear fit through
    typical handbook values; constant outside 273–353 K.
    """
    pts = [(273.15, 9.5e-3), (293.15, 4.3e-3), (313.15, 2.4e-3),
           (333.15, 1.5e-3), (353.15, 1.0e-3)]
    if T_K <= pts[0][0]:
        return pts[0][1]
    if T_K >= pts[-1][0]:
        return pts[-1][1]
    for (t0, v0), (t1, v1) in zip(pts, pts[1:]):
        if t0 <= T_K <= t1:
            f = (T_K - t0) / (t1 - t0)
            return v0 + f * (v1 - v0)
    return pts[-1][1]


class FallbackProvider:
    """Built-in property tables for use when CoolProp is unavailable.

    Supported fluids: ``Water``, ``WaterGlycol50``.
    """

    name = "Fallback"

    _TABLE = {
        "Water": (_water_rho, _water_mu),
        "WaterGlycol50": (_glycol50_rho, _glycol50_mu),
    }

    @classmethod
    def supported_fluids(cls) -> list[str]:
        return list(cls._TABLE.keys())

    def get_rho_mu(self, fluid_name: str, T_K: float) -> Tuple[float, float]:
        try:
            rho_fn, mu_fn = self._TABLE[fluid_name]
        except KeyError as exc:
            raise ValueError(
                f"Fluid {fluid_name!r} not in fallback table. "
                f"Supported: {self.supported_fluids()}"
            ) from exc
        return rho_fn(T_K), mu_fn(T_K)


# ---------------------------------------------------------------------------
# Top-level cached helper
# ---------------------------------------------------------------------------
@lru_cache(maxsize=128)
def _cached_rho_mu(fluid_name: str, T_K: float, prefer_coolprop: bool) -> Tuple[float, float]:
    if prefer_coolprop and _HAS_COOLPROP:
        try:
            return CoolPropProvider().get_rho_mu(fluid_name, T_K)
        except Exception as exc:
            _logger.warning("CoolProp failed for %s @ %.2f K (%s); falling back.",
                            fluid_name, T_K, exc)
    return FallbackProvider().get_rho_mu(fluid_name, T_K)


def get_fluid_state(fluid_name: str, T_K: float, *, prefer_coolprop: bool = True) -> FluidState:
    """Return a :class:`FluidState` for ``fluid_name`` at temperature ``T_K``.

    Uses CoolProp when available unless ``prefer_coolprop`` is False; otherwise
    falls back to the built-in tables. Results are cached.
    """
    rho, mu = _cached_rho_mu(fluid_name, float(T_K), bool(prefer_coolprop))
    return FluidState(fluid_name=fluid_name, T_K=float(T_K), rho=rho, mu=mu)


def coolprop_available() -> bool:
    """Whether CoolProp could be imported successfully."""
    return _HAS_COOLPROP
