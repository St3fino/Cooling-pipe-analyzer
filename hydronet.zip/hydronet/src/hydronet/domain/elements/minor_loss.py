"""Minor-loss fittings: elbows, reducers, throttling valves and similar."""
from __future__ import annotations

import math
from typing import Any, Optional

from hydronet.domain.elements.base import Element
from hydronet.domain.fluid import FluidState
from hydronet.domain.libraries.k_fittings import get_K


class MinorLossElement(Element):
    """Element modelled by a single loss coefficient ``K`` referenced to
    velocity head ``ρ v² / 2`` at reference diameter ``D_ref_m``.

    Parameters
    ----------
    fitting_type
        Key for :func:`get_K` (e.g., ``Elbow90``, ``Reducer``).  Used only to
        provide a default ``K``.
    K_override
        Explicit ``K`` value bypassing the library lookup.
    D_ref_m
        Reference diameter (m) used to compute the velocity head.
    """

    type_name = "MinorLoss"

    def __init__(self, *, id: str, name: str, from_node: str, to_node: str,
                 fitting_type: str, D_ref_m: float, K_override: Optional[float] = None,
                 enabled: bool = True) -> None:
        super().__init__(id=id, name=name, from_node=from_node,
                         to_node=to_node, enabled=enabled)
        if D_ref_m <= 0:
            raise ValueError("D_ref_m must be > 0 for a MinorLossElement")
        self.fitting_type = fitting_type
        self.D_ref_m = float(D_ref_m)
        self.K = float(K_override) if K_override is not None else float(get_K(fitting_type))
        if self.K < 0:
            raise ValueError("K must be non-negative")

    # ------------------------------------------------------------------
    @property
    def area(self) -> float:
        return math.pi * self.D_ref_m ** 2 / 4.0

    # ------------------------------------------------------------------
    def dp(self, Q: float, fluid: FluidState) -> float:
        if Q <= 0.0:
            return 0.0
        v = Q / self.area
        return self.K * (fluid.rho * v * v / 2.0)

    # ------------------------------------------------------------------
    def compute_diagnostics(self, Q: float, fluid: FluidState) -> dict[str, Any]:
        v = Q / self.area if Q > 0 else 0.0
        dp = self.dp(Q, fluid)
        return {
            "id": self.id,
            "type": self.type_name,
            "Q": float(Q),
            "v": float(v),
            "K": self.K,
            "D": self.D_ref_m,
            "dp_minor": float(dp),
            "dp": float(dp),
            "notes": f"fitting={self.fitting_type}",
        }

    def describe(self) -> dict[str, Any]:
        d = super().describe()
        d.update({"fitting_type": self.fitting_type, "K": self.K,
                  "D_ref_m": self.D_ref_m})
        return d
