"""Abstract base class for all hydraulic elements."""
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from hydronet.domain.fluid import FluidState


class Element(ABC):
    """Abstract hydraulic element.

    Subclasses implement :meth:`dp` returning the **pressure drop** across the
    element (positive for passive elements, negative for pumps) at flow ``Q``
    (m^3/s, non-negative, oriented from ``from_node`` to ``to_node``).
    """

    #: Short string used for serialization and reporting.
    type_name: str = "Element"

    def __init__(self, *, id: str, name: str, from_node: str, to_node: str,
                 enabled: bool = True) -> None:
        self.id = id
        self.name = name
        self.from_node = from_node
        self.to_node = to_node
        self.enabled = enabled

    # ------------------------------------------------------------------
    # Required API
    # ------------------------------------------------------------------
    @abstractmethod
    def dp(self, Q: float, fluid: FluidState) -> float:
        """Pressure drop (Pa) at volumetric flow ``Q`` (m^3/s)."""
        raise NotImplementedError

    # ------------------------------------------------------------------
    # Optional API — default implementation uses finite difference
    # ------------------------------------------------------------------
    def ddp_dQ(self, Q: float, fluid: FluidState, *, h: float = 1e-6) -> float:
        """Derivative of dp w.r.t. Q. Default implementation uses central FD."""
        if Q - h < 0.0:
            return (self.dp(Q + h, fluid) - self.dp(Q, fluid)) / h
        return (self.dp(Q + h, fluid) - self.dp(Q - h, fluid)) / (2.0 * h)

    # ------------------------------------------------------------------
    # Diagnostics & serialization
    # ------------------------------------------------------------------
    def compute_diagnostics(self, Q: float, fluid: FluidState) -> dict[str, Any]:
        """Return a dict with element-specific diagnostic values at flow Q."""
        return {"id": self.id, "type": self.type_name, "Q": float(Q),
                "dp": float(self.dp(Q, fluid))}

    def describe(self) -> dict[str, Any]:
        """Serializable description of the element parameters."""
        return {
            "id": self.id,
            "type": self.type_name,
            "name": self.name,
            "from_node": self.from_node,
            "to_node": self.to_node,
            "enabled": self.enabled,
        }

    def __repr__(self) -> str:  # pragma: no cover - cosmetic
        return (f"<{self.__class__.__name__} id={self.id!r} "
                f"{self.from_node}->{self.to_node}>")
