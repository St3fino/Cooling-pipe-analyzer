"""Curve-based passive component (dp vs Q) defined by table or polynomial."""
from __future__ import annotations

from typing import Any, Optional

import numpy as np

from hydronet.domain.elements.base import Element
from hydronet.domain.fluid import FluidState
from hydronet.solver.curvefit import build_dp_curve


class CurveComponentElement(Element):
    """Generic Δp–Q component.

    Provide either:

    * ``Q_points`` and ``dp_points`` (tabulated) — interpolated by PCHIP when
      monotone increasing, linear with a warning otherwise.
    * ``poly_coeffs`` — ascending-order polynomial coefficients such that
      ``dp(Q) = c0 + c1*Q + c2*Q^2 + …``.  Quadratic-only is recommended;
      higher orders are accepted at the user's risk.
    """

    type_name = "CurveComponent"

    def __init__(self, *, id: str, name: str, from_node: str, to_node: str,
                 Q_points: Optional[list[float]] = None,
                 dp_points: Optional[list[float]] = None,
                 poly_coeffs: Optional[list[float]] = None,
                 enabled: bool = True) -> None:
        super().__init__(id=id, name=name, from_node=from_node,
                         to_node=to_node, enabled=enabled)
        if poly_coeffs is None and (Q_points is None or dp_points is None):
            raise ValueError("Provide either (Q_points, dp_points) or poly_coeffs")
        self.Q_points = list(Q_points) if Q_points is not None else None
        self.dp_points = list(dp_points) if dp_points is not None else None
        self.poly_coeffs = list(poly_coeffs) if poly_coeffs is not None else None
        self.warnings: list[str] = []
        self._evaluator, w = build_dp_curve(
            Q_points=self.Q_points, dp_points=self.dp_points,
            poly_coeffs=self.poly_coeffs, kind="dp",
        )
        if w:
            self.warnings.append(w)

    # ------------------------------------------------------------------
    def dp(self, Q: float, fluid: FluidState) -> float:
        if Q <= 0.0:
            # Component dp at zero flow is defined as the curve value at 0.
            # Negative values are clipped to zero for stability.
            return max(0.0, float(self._evaluator(0.0)))
        return float(self._evaluator(float(Q)))

    # ------------------------------------------------------------------
    def compute_diagnostics(self, Q: float, fluid: FluidState) -> dict[str, Any]:
        dp = self.dp(Q, fluid)
        notes = "; ".join(self.warnings) if self.warnings else None
        return {
            "id": self.id,
            "type": self.type_name,
            "Q": float(Q),
            "dp": float(dp),
            "notes": notes,
        }

    def describe(self) -> dict[str, Any]:
        d = super().describe()
        d.update({"Q_points": self.Q_points, "dp_points": self.dp_points,
                  "poly_coeffs": self.poly_coeffs})
        return d
