"""Pump element with dp_rise(Q) curve from table (dp or head) or polynomial."""
from __future__ import annotations

from typing import Any, Optional

import numpy as np

from hydronet.config import G_ACCEL
from hydronet.domain.elements.base import Element
from hydronet.domain.fluid import FluidState
from hydronet.solver.curvefit import build_dp_curve


class PumpElement(Element):
    """Active pump element.

    The pump curve can be supplied as:

    * ``Q_points`` + ``dp_rise_points``  (Pa) — preferred for full generality.
    * ``Q_points`` + ``H_points``        (m head) — converted to Δp using
      ``ρ · g · H`` at evaluation time.
    * ``poly_coeffs`` — ascending-order polynomial coefficients of dp_rise(Q).

    Convention
    ----------
    ``dp_rise(Q)`` is the **positive** pressure rise produced by the pump.
    Because the tree solver uses pressure-drop conventions, :meth:`dp` returns
    ``-dp_rise(Q)`` so the pump contributes negative drop along the tree.
    """

    type_name = "Pump"

    def __init__(self, *, id: str, name: str, from_node: str, to_node: str,
                 Q_points: Optional[list[float]] = None,
                 dp_rise_points: Optional[list[float]] = None,
                 H_points: Optional[list[float]] = None,
                 poly_coeffs: Optional[list[float]] = None,
                 enabled: bool = True) -> None:
        super().__init__(id=id, name=name, from_node=from_node,
                         to_node=to_node, enabled=enabled)
        provided = sum(x is not None for x in (dp_rise_points, H_points, poly_coeffs))
        if provided == 0:
            raise ValueError(
                "Pump requires one of: dp_rise_points, H_points (with Q_points), or poly_coeffs"
            )
        if provided > 1:
            raise ValueError("Provide exactly one of dp_rise_points, H_points, poly_coeffs")
        if (dp_rise_points is not None or H_points is not None) and Q_points is None:
            raise ValueError("Q_points required when supplying a tabulated pump curve")
        self.Q_points = list(Q_points) if Q_points is not None else None
        self.dp_rise_points = list(dp_rise_points) if dp_rise_points is not None else None
        self.H_points = list(H_points) if H_points is not None else None
        self.poly_coeffs = list(poly_coeffs) if poly_coeffs is not None else None
        self.warnings: list[str] = []

        # If we received head data, build the evaluator lazily at use-time
        # (depends on fluid rho).  Otherwise, build now.
        self._dprise_evaluator = None
        if self.H_points is None:
            self._dprise_evaluator, w = build_dp_curve(
                Q_points=self.Q_points, dp_points=self.dp_rise_points,
                poly_coeffs=self.poly_coeffs, kind="pump",
            )
            if w:
                self.warnings.append(w)

    # ------------------------------------------------------------------
    def dp_rise(self, Q: float, fluid: FluidState) -> float:
        """Pump pressure rise (Pa, positive) at flow ``Q``."""
        if self.H_points is not None:
            # Build evaluator on the fly with current fluid rho
            dp_rise_pts = [fluid.rho * G_ACCEL * h for h in self.H_points]
            evaluator, w = build_dp_curve(Q_points=self.Q_points,
                                          dp_points=dp_rise_pts, kind="pump")
            if w and w not in self.warnings:
                self.warnings.append(w)
            return max(0.0, float(evaluator(max(0.0, float(Q)))))
        assert self._dprise_evaluator is not None
        return max(0.0, float(self._dprise_evaluator(max(0.0, float(Q)))))

    # ------------------------------------------------------------------
    def dp(self, Q: float, fluid: FluidState) -> float:
        # Negative drop = pressure rise.
        return -self.dp_rise(Q, fluid)

    # ------------------------------------------------------------------
    def compute_diagnostics(self, Q: float, fluid: FluidState) -> dict[str, Any]:
        rise = self.dp_rise(Q, fluid)
        notes = "; ".join(self.warnings) if self.warnings else None
        return {
            "id": self.id,
            "type": self.type_name,
            "Q": float(Q),
            "dp": float(-rise),
            "dp_rise": float(rise),
            "notes": notes,
        }

    def describe(self) -> dict[str, Any]:
        d = super().describe()
        d.update({"Q_points": self.Q_points, "dp_rise_points": self.dp_rise_points,
                  "H_points": self.H_points, "poly_coeffs": self.poly_coeffs})
        return d
