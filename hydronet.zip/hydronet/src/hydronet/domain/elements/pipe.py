"""Straight-pipe element using Darcy–Weisbach with the Churchill explicit friction factor."""
from __future__ import annotations

import math
from typing import Any, Optional

from hydronet.config import RE_MIN
from hydronet.domain.elements.base import Element
from hydronet.domain.fluid import FluidState
from hydronet.domain.libraries.materials import get_roughness


class PipeElement(Element):
    """A straight constant-diameter pipe.

    Parameters
    ----------
    L_m
        Length (m).
    D_m
        Internal diameter (m).
    material
        Material key from :mod:`hydronet.domain.libraries.materials`. The
        roughness ``eps_m`` is looked up unless ``eps_m`` is given explicitly.
    eps_m
        Override absolute roughness in metres.
    """

    type_name = "Pipe"

    def __init__(self, *, id: str, name: str, from_node: str, to_node: str,
                 L_m: float, D_m: float, material: str = "SteelCommercial",
                 eps_m: Optional[float] = None, enabled: bool = True) -> None:
        super().__init__(id=id, name=name, from_node=from_node,
                         to_node=to_node, enabled=enabled)
        if L_m <= 0:
            raise ValueError("Pipe length L_m must be > 0")
        if D_m <= 0:
            raise ValueError("Pipe diameter D_m must be > 0")
        self.L_m = float(L_m)
        self.D_m = float(D_m)
        self.material = material
        self.eps_m = float(eps_m) if eps_m is not None else float(get_roughness(material))

    # ------------------------------------------------------------------
    @property
    def area(self) -> float:
        """Internal cross-section area (m^2)."""
        return math.pi * self.D_m ** 2 / 4.0

    # ------------------------------------------------------------------
    # Friction factor — Churchill (explicit, all-regime)
    # ------------------------------------------------------------------
    def churchill_f(self, Re: float) -> float:
        """Churchill (1977) friction factor — single explicit formula for all Re."""
        Re = max(Re, RE_MIN)
        eps_over_D = self.eps_m / self.D_m
        A = (2.457 * math.log(1.0 / ((7.0 / Re) ** 0.9 + 0.27 * eps_over_D))) ** 16
        B = (37530.0 / Re) ** 16
        inner = (8.0 / Re) ** 12 + 1.0 / (A + B) ** 1.5
        return 8.0 * inner ** (1.0 / 12.0)

    # ------------------------------------------------------------------
    def dp(self, Q: float, fluid: FluidState) -> float:
        if Q <= 0.0:
            return 0.0
        v = Q / self.area
        Re = fluid.rho * v * self.D_m / fluid.mu
        f = self.churchill_f(Re)
        return f * (self.L_m / self.D_m) * (fluid.rho * v * v / 2.0)

    # ------------------------------------------------------------------
    def compute_diagnostics(self, Q: float, fluid: FluidState) -> dict[str, Any]:
        v = Q / self.area if Q > 0 else 0.0
        Re = (fluid.rho * v * self.D_m / fluid.mu) if v > 0 else 0.0
        f = self.churchill_f(Re) if Re > 0 else float("nan")
        dp = self.dp(Q, fluid)
        return {
            "id": self.id,
            "type": self.type_name,
            "Q": float(Q),
            "v": float(v),
            "Re": float(Re),
            "f": float(f) if f == f else None,  # NaN-safe
            "L": self.L_m,
            "D": self.D_m,
            "eps": self.eps_m,
            "dp_major": float(dp),
            "dp": float(dp),
        }

    def describe(self) -> dict[str, Any]:
        d = super().describe()
        d.update({"L_m": self.L_m, "D_m": self.D_m, "material": self.material,
                  "eps_m": self.eps_m})
        return d
