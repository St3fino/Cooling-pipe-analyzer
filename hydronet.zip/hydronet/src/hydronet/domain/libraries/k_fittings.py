"""Minimal K-factor library for common pipe fittings.

These are engineering defaults; users should always be able to override the
value at the element level.
"""
from __future__ import annotations

#: Approximate loss coefficients K (dimensionless) at the reference diameter.
FITTING_K: dict[str, float] = {
    "Elbow90": 0.9,
    "Elbow45": 0.4,
    "Reducer": 0.5,
    "Expander": 1.0,
    "ThrottleValve": 5.0,
    "GenericValveOpen": 0.2,
    "GateValveOpen": 0.15,
    "BallValveOpen": 0.05,
    "TeeRun": 0.6,
    "TeeBranch": 1.8,
    "Entrance": 0.5,
    "Exit": 1.0,
    "CheckValve": 2.0,
}


def get_K(fitting_type: str) -> float:
    """Return default K for ``fitting_type`` or raise ``KeyError``."""
    try:
        return FITTING_K[fitting_type]
    except KeyError as exc:
        raise KeyError(
            f"Unknown fitting {fitting_type!r}. "
            f"Known: {sorted(FITTING_K)}"
        ) from exc


def available_fittings() -> list[str]:
    return sorted(FITTING_K)
