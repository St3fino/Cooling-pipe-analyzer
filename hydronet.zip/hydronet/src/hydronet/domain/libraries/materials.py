"""Minimal material absolute-roughness library (ε in metres).

Values are approximate engineering defaults and must be overridable per-pipe.
"""
from __future__ import annotations

#: Absolute roughness in metres for common commercial materials.
MATERIAL_ROUGHNESS: dict[str, float] = {
    "SteelCommercial": 4.6e-5,
    "StainlessSteel": 1.5e-5,
    "Aluminum": 1.5e-6,
    "Copper": 1.5e-6,
    "PVC": 5.0e-6,
    "Plastic": 5.0e-6,
    "RubberHose": 1.0e-5,
    "CastIron": 2.6e-4,
    "ConcreteSmooth": 3.0e-4,
}


def get_roughness(material: str) -> float:
    """Return roughness ε (m) for ``material`` or raise ``KeyError``."""
    try:
        return MATERIAL_ROUGHNESS[material]
    except KeyError as exc:
        raise KeyError(
            f"Unknown material {material!r}. "
            f"Known: {sorted(MATERIAL_ROUGHNESS)}"
        ) from exc


def available_materials() -> list[str]:
    return sorted(MATERIAL_ROUGHNESS)
