"""Streamlit wizard for hydronet.

A five-step wizard that exercises ``hydronet`` end-to-end:

    1. Fluid selection
    2. Network building (with preset)
    3. Validation
    4. Solve mode selection (A / B / C)
    5. Run + display + CSV download

The UI talks **only** to ``hydronet.app.use_cases`` (Builder, Runner, Exporter)
and ``hydronet.app.validation``. All physics live behind that boundary.

Run with::

    streamlit run src/hydronet/ui/streamlit_app.py
"""
from __future__ import annotations

import json

import pandas as pd
import streamlit as st

from hydronet.app.use_cases import (
    Exporter,
    NetworkBuilder,
    ScenarioRunner,
    build_preset_demo,
)
from hydronet.app.validation import validate_tree
from hydronet.domain.network import NetworkError
from hydronet.ui.widgets import (
    curve_component_form,
    minor_loss_form,
    pipe_form,
    pump_form,
)

STEPS = [
    "1 · Fluid",
    "2 · Build network",
    "3 · Validate",
    "4 · Solve mode",
    "5 · Run & export",
]


# ---------------------------------------------------------------------------
# Session-state helpers
# ---------------------------------------------------------------------------
def _builder() -> NetworkBuilder:
    if "builder" not in st.session_state:
        st.session_state.builder = NetworkBuilder()
    return st.session_state.builder


def _reset_builder() -> None:
    st.session_state.builder = NetworkBuilder()
    st.session_state.pop("result", None)
    st.session_state.pop("validation", None)


# ---------------------------------------------------------------------------
# Step 1 — Fluid
# ---------------------------------------------------------------------------
def step_fluid() -> None:
    st.header("Step 1 — Fluid")
    st.write(
        "Pick the working fluid and temperature. If CoolProp is installed it "
        "will be used; otherwise a built-in fallback table is consulted."
    )
    fluid_name = st.selectbox("Fluid", ["Water", "WaterGlycol50"], index=0)
    T_C = st.number_input("Temperature (°C)", value=20.0, step=1.0)
    if st.button("Set fluid"):
        try:
            fs = _builder().create_new_project(fluid_name, T_C=T_C)
            st.success(
                f"Fluid set: {fs.fluid_name} @ {T_C:.1f} °C  "
                f"→  ρ = {fs.rho:.2f} kg/m³, μ = {fs.mu:.3e} Pa·s"
            )
        except Exception as exc:  # noqa: BLE001
            st.error(f"Could not compute fluid properties: {exc}")

    if (fs := _builder().fluid_state) is not None:
        st.info(
            f"Current fluid: **{fs.fluid_name}**  ρ={fs.rho:.2f} kg/m³  "
            f"μ={fs.mu:.3e} Pa·s  T={fs.T_K - 273.15:.1f} °C"
        )


# ---------------------------------------------------------------------------
# Step 2 — Build network
# ---------------------------------------------------------------------------
def step_build() -> None:
    st.header("Step 2 — Build network")
    col_a, col_b = st.columns([1, 1])

    with col_a:
        if st.button("📦 Load preset demo network"):
            _reset_builder()
            st.session_state.builder = build_preset_demo()
            st.success("Preset demo loaded — go to step 3 to validate.")
    with col_b:
        if st.button("🗑️ Reset network"):
            _reset_builder()
            st.info("Network cleared.")

    builder = _builder()

    # ----- existing nodes/elements summary
    with st.expander("Current network", expanded=True):
        nodes = builder.network.nodes
        if not nodes:
            st.caption("(empty)")
        else:
            st.write("**Nodes**")
            st.dataframe(
                pd.DataFrame(
                    [{"id": n.id, "name": n.name, "kind": n.kind,
                      "p_fixed (Pa)": n.p_fixed} for n in nodes.values()]
                ),
                use_container_width=True,
            )
        elements = builder.network.elements
        if elements:
            st.write("**Elements**")
            st.dataframe(
                pd.DataFrame([
                    {"id": e.id, "name": e.name, "type": type(e).__name__,
                     "from": e.from_node, "to": e.to_node}
                    for e in elements.values()
                ]),
                use_container_width=True,
            )

    # ----- add node form
    st.subheader("Add node")
    nc1, nc2, nc3 = st.columns(3)
    with nc1:
        kind = st.selectbox("Kind", ["root", "junction", "leaf"], index=1)
    with nc2:
        name = st.text_input("Name (optional)", value="")
    with nc3:
        p_fixed_str = st.text_input(
            "p_fixed (Pa, leaf only)", value="",
            help="Required for leaves. Leave empty for root/junction.",
        )
    if st.button("Add node"):
        p_fixed = float(p_fixed_str) if p_fixed_str.strip() else None
        try:
            node = builder.add_node(kind=kind, name=name or None,
                                    p_fixed=p_fixed)
            st.success(f"Added node {node.id} ({node.kind}).")
        except NetworkError as exc:
            st.error(f"Network error: {exc}")
        except Exception as exc:  # noqa: BLE001
            st.error(f"Could not add node: {exc}")

    # ----- add element form
    st.subheader("Add element")
    node_ids = list(builder.network.nodes.keys())
    if len(node_ids) < 2:
        st.caption("Add at least two nodes before creating elements.")
        return

    ec1, ec2, ec3 = st.columns(3)
    with ec1:
        from_node = st.selectbox("From node", node_ids, key="el_from")
    with ec2:
        to_node = st.selectbox("To node", node_ids, key="el_to",
                               index=min(1, len(node_ids) - 1))
    with ec3:
        el_type = st.selectbox(
            "Element type",
            ["Pipe", "Minor loss", "Curve component", "Pump"],
            key="el_type",
        )
    el_name = st.text_input("Element name (optional)", key="el_name")

    kwargs: dict | None = None
    if el_type == "Pipe":
        kwargs = pipe_form(key_prefix="pipe_form")
    elif el_type == "Minor loss":
        kwargs = minor_loss_form(key_prefix="ml_form")
    elif el_type == "Curve component":
        kwargs = curve_component_form(key_prefix="cc_form")
    elif el_type == "Pump":
        kwargs = pump_form(key_prefix="pump_form")

    if st.button("Add element"):
        if kwargs is None:
            st.error("Fill in the element parameters first.")
            return
        try:
            if el_type == "Pipe":
                el = builder.add_pipe(from_node, to_node,
                                      name=el_name or None, **kwargs)
            elif el_type == "Minor loss":
                el = builder.add_minor_loss(from_node, to_node,
                                            name=el_name or None, **kwargs)
            elif el_type == "Curve component":
                el = builder.add_curve_component(from_node, to_node,
                                                 name=el_name or None,
                                                 **kwargs)
            else:  # Pump
                el = builder.add_pump(from_node, to_node,
                                      name=el_name or None, **kwargs)
            st.success(f"Added {type(el).__name__} {el.id}.")
        except NetworkError as exc:
            st.error(
                f"❌ Network error: {exc}\n\n"
                "Tip: hydronet's MVP only supports **tree** networks. "
                "Cycles and multi-parent nodes are rejected. "
                "If you intended to close a loop back to the pump, replace "
                "the closing segment with a *leaf* node having `p_fixed`."
            )
        except Exception as exc:  # noqa: BLE001
            st.error(f"Could not add element: {exc}")


# ---------------------------------------------------------------------------
# Step 3 — Validate
# ---------------------------------------------------------------------------
def step_validate() -> None:
    st.header("Step 3 — Validate network")
    builder = _builder()
    if st.button("Run validation"):
        report = validate_tree(builder.network)
        st.session_state.validation = report

    report = st.session_state.get("validation")
    if report is None:
        st.caption("Click *Run validation* to check the network.")
        return

    if report.ok:
        st.success("✅ Network is a valid tree.")
    else:
        st.error("❌ Network is not a valid tree.")
    if report.errors:
        st.markdown("**Errors**")
        for e in report.errors:
            st.write(f"- {e}")
    if report.warnings:
        st.markdown("**Warnings**")
        for w in report.warnings:
            st.write(f"- {w}")
    if report.summary:
        st.markdown("**Summary**")
        st.json(report.summary)


# ---------------------------------------------------------------------------
# Step 4 + 5 — Solve and display
# ---------------------------------------------------------------------------
def step_solve() -> None:
    st.header("Step 4 — Solve mode")
    builder = _builder()
    if builder.fluid_state is None:
        st.error("No fluid set. Go to step 1.")
        return

    mode = st.radio(
        "Solve mode",
        ["Mode A — given Q, compute Δp",
         "Mode B — given Δp, compute Q",
         "Mode C — pump operating point"],
    )
    st.session_state["solve_mode"] = mode

    if mode.startswith("Mode A"):
        Q_lpm = st.number_input("Q (L/min)", min_value=0.0, value=10.0,
                                step=1.0)
        st.session_state["solve_param"] = {"Q": Q_lpm / 60000.0}
    elif mode.startswith("Mode B"):
        dp_bar = st.number_input("Δp target (bar)", min_value=0.0, value=1.0,
                                 step=0.1)
        st.session_state["solve_param"] = {"dp_target": dp_bar * 1e5}
    else:
        pump_ids = [eid for eid, el in builder.network.elements.items()
                    if type(el).__name__ == "PumpElement"]
        if not pump_ids:
            st.error("No PumpElement in the network — add one first.")
            return
        pump_id = st.selectbox("Pump element", pump_ids)
        p_root_bar = st.number_input("Root reference pressure (bar)",
                                     value=0.0, step=0.1)
        p_leaf_bar = st.number_input("Leaf fixed pressure (bar)",
                                     value=0.0, step=0.1)
        st.session_state["solve_param"] = {
            "pump_element_id": pump_id,
            "p_root_fixed": p_root_bar * 1e5,
            "p_leaf_fixed": p_leaf_bar * 1e5,
        }


def step_run() -> None:
    st.header("Step 5 — Run & export")
    builder = _builder()
    mode = st.session_state.get("solve_mode")
    param = st.session_state.get("solve_param")
    if mode is None or param is None:
        st.caption("Configure step 4 first.")
        return

    if st.button("▶ Run simulation"):
        try:
            network = builder.finalize()
        except NetworkError as exc:
            st.error(f"Network is not valid: {exc}")
            return
        fluid = builder.fluid_state
        assert fluid is not None
        try:
            if mode.startswith("Mode A"):
                result = ScenarioRunner.run_mode_a(network, fluid, **param)
            elif mode.startswith("Mode B"):
                result = ScenarioRunner.run_mode_b(network, fluid, **param)
            else:
                result = ScenarioRunner.run_mode_c(network, fluid, **param)
            st.session_state.result = result
        except Exception as exc:  # noqa: BLE001
            st.error(f"Solver failed: {exc}")
            return

    result = st.session_state.get("result")
    if result is None:
        return

    sys_ = result.system
    c1, c2, c3 = st.columns(3)
    c1.metric("Mode", sys_.mode)
    c2.metric("Q_total (L/min)", f"{sys_.Q_total * 60000.0:.3f}")
    c3.metric("Δp_total (bar)", f"{sys_.dp_total / 1e5:.4f}")

    if sys_.warnings:
        with st.expander("⚠️ Solver warnings", expanded=False):
            for w in sys_.warnings:
                st.write(f"- {w}")

    st.subheader("Per-element diagnostics")
    el_df = Exporter.to_elements_dataframe(result)
    st.dataframe(el_df, use_container_width=True)

    st.subheader("Per-branch summary")
    br_df = Exporter.to_branches_dataframe(result)
    st.dataframe(br_df, use_container_width=True)

    # ----- downloads
    st.subheader("Downloads")
    st.download_button(
        "⬇ elements.csv",
        data=el_df.to_csv(index=False).encode("utf-8"),
        file_name="elements.csv",
        mime="text/csv",
    )
    st.download_button(
        "⬇ branches.csv",
        data=br_df.to_csv(index=False).encode("utf-8"),
        file_name="branches.csv",
        mime="text/csv",
    )

    # ----- project save
    try:
        proj_json = Exporter.save_project(
            builder.network, builder.fluid_state,  # type: ignore[arg-type]
            metadata={"mode": sys_.mode},
        )
        st.download_button(
            "💾 project.json",
            data=proj_json.encode("utf-8"),
            file_name="project.json",
            mime="application/json",
        )
    except Exception as exc:  # noqa: BLE001
        st.caption(f"(Could not serialize project: {exc})")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
def main() -> None:
    st.set_page_config(page_title="hydronet", layout="wide")
    st.title("hydronet — hydraulic Δp wizard")

    step = st.sidebar.radio("Wizard", STEPS, index=0)
    st.sidebar.markdown("---")
    st.sidebar.markdown(
        "**About**\n\n"
        "1D incompressible pressure-drop solver for tree networks. "
        "MVP — no loops, no elevation. Use a *leaf with p_fixed* in place of "
        "a closing return line."
    )

    # ----- project load
    with st.sidebar.expander("Load project.json"):
        upl = st.file_uploader("project.json", type=["json"],
                               key="proj_upload")
        if upl is not None and st.button("Load"):
            try:
                payload = upl.read().decode("utf-8")
                # quick syntax check
                json.loads(payload)
                network, fluid = Exporter.load_project(payload)
                _reset_builder()
                b = _builder()
                b.network = network
                b.fluid_state = fluid
                st.success("Project loaded.")
            except Exception as exc:  # noqa: BLE001
                st.error(f"Load failed: {exc}")

    if step == STEPS[0]:
        step_fluid()
    elif step == STEPS[1]:
        step_build()
    elif step == STEPS[2]:
        step_validate()
    elif step == STEPS[3]:
        step_solve()
    else:
        step_run()


if __name__ == "__main__":
    main()
