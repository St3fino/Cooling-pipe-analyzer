"""Streamlit UI package — thin wrapper around ``hydronet.app.use_cases``."""
