"""Reusable Streamlit widgets.

These helpers render small form fragments and return validated values. They
keep ``streamlit_app.py`` short and make each element-type form testable.
"""
from __future__ import annotations

from io import StringIO
from typing import Optional

import pandas as pd
import streamlit as st

from hydronet.domain.libraries.k_fittings import available_fittings
from hydronet.domain.libraries.materials import available_materials


# ---------------------------------------------------------------------------
# Curve input (table or polynomial)
# ---------------------------------------------------------------------------
def curve_input(
    *,
    key_prefix: str,
    label: str = "Curve",
    dp_label: str = "dp (Pa)",
) -> tuple[Optional[list[float]], Optional[list[float]], Optional[list[float]]]:
    """Render a curve-input fragment.

    Returns a triple ``(Q_points, dp_points, poly_coeffs)`` where exactly one
    of the two representations is populated. Returns all-``None`` when the
    user has not yet provided valid input.
    """
    mode = st.radio(
        f"{label} — input mode",
        ["Table (Q, dp)", "Polynomial (a0 + a1·Q + a2·Q² …)"],
        key=f"{key_prefix}_mode",
        horizontal=True,
    )

    if mode == "Table (Q, dp)":
        return *_table_curve_input(key_prefix, dp_label), None
    return None, None, _poly_curve_input(key_prefix)


def _table_curve_input(
    key_prefix: str, dp_label: str
) -> tuple[Optional[list[float]], Optional[list[float]]]:
    st.caption(
        "Paste CSV with two columns (`Q,dp`) **or** edit the table below. "
        "Q is in m³/s."
    )
    csv_text = st.text_area(
        "Paste CSV (optional)",
        key=f"{key_prefix}_csv",
        height=80,
        placeholder="Q,dp\n0.0,0.0\n0.001,1000\n0.002,4000",
    )
    if csv_text.strip():
        try:
            df = pd.read_csv(StringIO(csv_text))
        except Exception as exc:  # noqa: BLE001
            st.error(f"Could not parse CSV: {exc}")
            return None, None
        if df.shape[1] < 2:
            st.error("CSV must have at least two columns: Q, dp")
            return None, None
        Q = df.iloc[:, 0].astype(float).tolist()
        dp = df.iloc[:, 1].astype(float).tolist()
        st.dataframe(pd.DataFrame({"Q": Q, dp_label: dp}), height=180)
        return Q, dp

    # Editable default table
    default = pd.DataFrame(
        {"Q (m³/s)": [0.0, 1e-3, 2e-3, 3e-3], dp_label: [0.0, 1e3, 4e3, 9e3]}
    )
    edited = st.data_editor(
        default,
        key=f"{key_prefix}_table",
        num_rows="dynamic",
        use_container_width=True,
    )
    try:
        Q = edited.iloc[:, 0].astype(float).tolist()
        dp = edited.iloc[:, 1].astype(float).tolist()
    except Exception as exc:  # noqa: BLE001
        st.error(f"Invalid numeric values in table: {exc}")
        return None, None
    if len(Q) < 2:
        st.warning("Need at least 2 rows.")
        return None, None
    return Q, dp


def _poly_curve_input(key_prefix: str) -> Optional[list[float]]:
    st.caption(
        "Enter coefficients in ascending order of Q. "
        "Example for `dp = 400000 − 1e9·Q²`: `400000, 0, -1e9`."
    )
    text = st.text_input(
        "Coefficients (comma-separated)",
        key=f"{key_prefix}_poly",
        placeholder="400000, 0, -1e9",
    )
    if not text.strip():
        return None
    try:
        return [float(t.strip()) for t in text.split(",") if t.strip()]
    except ValueError as exc:
        st.error(f"Invalid number in coefficients: {exc}")
        return None


# ---------------------------------------------------------------------------
# Element-type forms
# ---------------------------------------------------------------------------
def pipe_form(*, key_prefix: str) -> Optional[dict]:
    """Render the pipe-creation form. Returns the kwargs dict on submit."""
    L_m = st.number_input("Length L (m)", min_value=0.0,
                          value=1.0, step=0.1, key=f"{key_prefix}_L")
    D_m = st.number_input("Internal diameter D (m)", min_value=1e-4,
                          value=0.050, step=0.001, format="%.4f",
                          key=f"{key_prefix}_D")
    material = st.selectbox(
        "Material", available_materials(), key=f"{key_prefix}_mat",
        index=0,
    )
    override = st.checkbox("Override roughness ε", key=f"{key_prefix}_ovr")
    eps_m: Optional[float] = None
    if override:
        eps_m = st.number_input(
            "Roughness ε (m)", min_value=0.0,
            value=4.6e-5, step=1e-6, format="%.7f",
            key=f"{key_prefix}_eps",
        )
    return {"L_m": L_m, "D_m": D_m, "material": material, "eps_m": eps_m}


def minor_loss_form(*, key_prefix: str) -> Optional[dict]:
    fitting_type = st.selectbox(
        "Fitting type", available_fittings(), key=f"{key_prefix}_ft",
    )
    D_ref_m = st.number_input(
        "Reference diameter D_ref (m)", min_value=1e-4,
        value=0.050, step=0.001, format="%.4f",
        key=f"{key_prefix}_Dref",
    )
    override = st.checkbox("Override K", key=f"{key_prefix}_ovr")
    K_override: Optional[float] = None
    if override:
        K_override = st.number_input(
            "K (override)", min_value=0.0, value=1.0, step=0.1,
            key=f"{key_prefix}_K",
        )
    return {"fitting_type": fitting_type, "D_ref_m": D_ref_m,
            "K_override": K_override}


def curve_component_form(*, key_prefix: str) -> Optional[dict]:
    Q, dp, poly = curve_input(key_prefix=key_prefix, label="Component dp(Q)")
    if poly is not None:
        return {"Q_points": None, "dp_points": None, "poly_coeffs": poly}
    if Q is not None and dp is not None:
        return {"Q_points": Q, "dp_points": dp, "poly_coeffs": None}
    return None


def pump_form(*, key_prefix: str) -> Optional[dict]:
    st.markdown("**Pump pressure-rise curve dp_rise(Q)**")
    use_head = st.checkbox(
        "Use head H(Q) [m] instead of dp_rise(Q) [Pa]",
        key=f"{key_prefix}_head",
    )
    dp_label = "H (m)" if use_head else "dp_rise (Pa)"
    Q, vals, poly = curve_input(
        key_prefix=key_prefix, label="Pump curve", dp_label=dp_label,
    )
    if poly is not None:
        return {"Q_points": None, "dp_rise_points": None,
                "H_points": None, "poly_coeffs": poly}
    if Q is not None and vals is not None:
        if use_head:
            return {"Q_points": Q, "dp_rise_points": None,
                    "H_points": vals, "poly_coeffs": None}
        return {"Q_points": Q, "dp_rise_points": vals,
                "H_points": None, "poly_coeffs": None}
    return None


__all__ = [
    "curve_input",
    "pipe_form",
    "minor_loss_form",
    "curve_component_form",
    "pump_form",
]
