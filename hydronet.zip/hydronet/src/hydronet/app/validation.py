"""Network validation utilities used by the UI before solving."""
from __future__ import annotations

from dataclasses import dataclass, field

from hydronet.domain.network import NetworkError, TreeNetwork


@dataclass
class ValidationReport:
    """Outcome of :func:`validate_tree`."""
    ok: bool = True
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    summary: dict = field(default_factory=dict)


def validate_tree(network: TreeNetwork) -> ValidationReport:
    """Return a :class:`ValidationReport` instead of raising.

    Useful for the UI which needs to display issues without crashing.
    """
    report = ValidationReport()
    try:
        network.validate_tree()
    except NetworkError as exc:
        report.ok = False
        report.errors.append(str(exc))
        return report

    # Soft checks ------------------------------------------------------
    if not network.nodes:
        report.ok = False
        report.errors.append("Network has no nodes.")
        return report

    if not network.elements:
        report.warnings.append("Network has no elements yet.")

    leaves = network.leaves()
    if not leaves:
        report.warnings.append("Network has no leaves.")
    else:
        leaves_without_pressure = [
            nid for nid in leaves
            if network.nodes[nid].p_fixed is None
        ]
        if leaves_without_pressure:
            report.warnings.append(
                f"Leaf nodes without p_fixed (assumed 0 Pa): {leaves_without_pressure}"
            )

    # Parallel junctions with mixed leaf pressures — flag for MVP
    for nid, children in network.children.items():
        if len(children) > 1:
            # Find all leaves under each child
            leaf_pressures: list[set[float | None]] = []
            for eid in children:
                sub_leaves = _leaves_under(network, network.elements[eid].to_node)
                leaf_pressures.append({network.nodes[lf].p_fixed for lf in sub_leaves})
            flat = {p for s in leaf_pressures for p in s if p is not None}
            if len(flat) > 1:
                report.warnings.append(
                    f"Parallel junction {nid!r} has mixed leaf pressures {sorted(flat)}; "
                    "MVP solver assumes equal leaf boundaries on parallel splits."
                )

    report.summary = network.summary()
    return report


def _leaves_under(network: TreeNetwork, nid: str) -> list[str]:
    out: list[str] = []
    stack = [nid]
    while stack:
        cur = stack.pop()
        kids = network.children.get(cur, [])
        if not kids:
            out.append(cur)
            continue
        for eid in kids:
            stack.append(network.elements[eid].to_node)
    return out
