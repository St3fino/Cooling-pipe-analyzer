"""Use-case layer — the only API the UI is allowed to talk to.

Three orchestrators:

* :class:`NetworkBuilder` — assemble a :class:`TreeNetwork` step-by-step.
* :class:`ScenarioRunner` — run a solve mode and return a :class:`SimulationResult`.
* :class:`Exporter` — write CSV files and JSON projects.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

from hydronet.domain.elements import (
    CurveComponentElement,
    Element,
    MinorLossElement,
    PipeElement,
    PumpElement,
)
from hydronet.domain.fluid import FluidState, get_fluid_state
from hydronet.domain.libraries.k_fittings import get_K
from hydronet.domain.network import Node, NetworkError, TreeNetwork
from hydronet.solver.tree_solver import (
    SimulationResult,
    SolveMode,
    TreeHydraulicSolver,
)
from hydronet.utils.units import c_to_k


# ---------------------------------------------------------------------------
# Builder
# ---------------------------------------------------------------------------
@dataclass
class NetworkBuilder:
    """Step-by-step builder for a project.

    Holds an in-progress :class:`TreeNetwork`, the chosen :class:`FluidState`,
    and bookkeeping for auto-generated ids.
    """

    fluid_name: str = "Water"
    T_C: float = 20.0
    prefer_coolprop: bool = True

    network: TreeNetwork = field(default_factory=TreeNetwork)
    fluid_state: Optional[FluidState] = None
    _node_counter: int = 0
    _elem_counter: int = 0

    # ------------------------------------------------------------------
    # Project / fluid
    # ------------------------------------------------------------------
    def create_new_project(self, fluid_name: str, T_C: float) -> FluidState:
        self.fluid_name = fluid_name
        self.T_C = float(T_C)
        self.fluid_state = get_fluid_state(
            fluid_name, c_to_k(T_C), prefer_coolprop=self.prefer_coolprop
        )
        self.network = TreeNetwork()
        self._node_counter = 0
        self._elem_counter = 0
        return self.fluid_state

    def ensure_fluid(self) -> FluidState:
        if self.fluid_state is None:
            self.fluid_state = get_fluid_state(
                self.fluid_name, c_to_k(self.T_C),
                prefer_coolprop=self.prefer_coolprop,
            )
        return self.fluid_state

    # ------------------------------------------------------------------
    # IDs
    # ------------------------------------------------------------------
    def _next_node_id(self) -> str:
        nid = f"n{self._node_counter}"
        self._node_counter += 1
        while nid in self.network.nodes:
            nid = f"n{self._node_counter}"
            self._node_counter += 1
        return nid

    def _next_elem_id(self) -> str:
        eid = f"e{self._elem_counter}"
        self._elem_counter += 1
        while eid in self.network.elements:
            eid = f"e{self._elem_counter}"
            self._elem_counter += 1
        return eid

    # ------------------------------------------------------------------
    # Nodes
    # ------------------------------------------------------------------
    def add_node(self, kind: str = "junction", name: Optional[str] = None,
                 p_fixed: Optional[float] = None,
                 node_id: Optional[str] = None) -> Node:
        nid = node_id or self._next_node_id()
        node = Node(id=nid, name=name or nid, kind=kind, p_fixed=p_fixed)  # type: ignore[arg-type]
        self.network.add_node(node)
        return node

    # ------------------------------------------------------------------
    # Elements
    # ------------------------------------------------------------------
    def add_pipe(self, from_node: str, to_node: str, *,
                 L_m: float, D_m: float, material: str = "SteelCommercial",
                 eps_m: Optional[float] = None,
                 name: Optional[str] = None) -> PipeElement:
        eid = self._next_elem_id()
        pipe = PipeElement(
            id=eid, name=name or eid, from_node=from_node, to_node=to_node,
            L_m=L_m, D_m=D_m, material=material, eps_m=eps_m,
        )
        self.network.add_element(pipe)
        return pipe

    def add_minor_loss(self, from_node: str, to_node: str, *,
                       fitting_type: str, D_ref_m: float,
                       K_override: Optional[float] = None,
                       name: Optional[str] = None) -> MinorLossElement:
        # default K is looked up by MinorLossElement when override is None.
        eid = self._next_elem_id()
        el = MinorLossElement(
            id=eid, name=name or eid, from_node=from_node, to_node=to_node,
            fitting_type=fitting_type, D_ref_m=D_ref_m, K_override=K_override,
        )
        self.network.add_element(el)
        return el

    def add_curve_component(self, from_node: str, to_node: str, *,
                            Q_points: Optional[list[float]] = None,
                            dp_points: Optional[list[float]] = None,
                            poly_coeffs: Optional[list[float]] = None,
                            name: Optional[str] = None) -> CurveComponentElement:
        eid = self._next_elem_id()
        el = CurveComponentElement(
            id=eid, name=name or eid, from_node=from_node, to_node=to_node,
            Q_points=Q_points, dp_points=dp_points, poly_coeffs=poly_coeffs,
        )
        self.network.add_element(el)
        return el

    def add_pump(self, from_node: str, to_node: str, *,
                 Q_points: Optional[list[float]] = None,
                 dp_rise_points: Optional[list[float]] = None,
                 H_points: Optional[list[float]] = None,
                 poly_coeffs: Optional[list[float]] = None,
                 name: Optional[str] = None) -> PumpElement:
        eid = self._next_elem_id()
        el = PumpElement(
            id=eid, name=name or eid, from_node=from_node, to_node=to_node,
            Q_points=Q_points, dp_rise_points=dp_rise_points,
            H_points=H_points, poly_coeffs=poly_coeffs,
        )
        self.network.add_element(el)
        return el

    # ------------------------------------------------------------------
    def finalize(self) -> TreeNetwork:
        """Validate the network and return it."""
        self.network.validate_tree()
        return self.network


# ---------------------------------------------------------------------------
# Runner
# ---------------------------------------------------------------------------
class ScenarioRunner:
    """Run solve scenarios on a finalized network."""

    @staticmethod
    def run_mode_a(network: TreeNetwork, fluid: FluidState, Q: float) -> SimulationResult:
        solver = TreeHydraulicSolver(network, fluid)
        return solver.solve_mode_a(Q)

    @staticmethod
    def run_mode_b(network: TreeNetwork, fluid: FluidState,
                   dp_target: float) -> SimulationResult:
        solver = TreeHydraulicSolver(network, fluid)
        return solver.solve_mode_b(dp_target)

    @staticmethod
    def run_mode_c(network: TreeNetwork, fluid: FluidState, *,
                   pump_element_id: str,
                   p_root_fixed: float = 0.0,
                   p_leaf_fixed: float = 0.0) -> SimulationResult:
        solver = TreeHydraulicSolver(network, fluid)
        return solver.solve_mode_c(
            pump_element_id,
            p_root_fixed=p_root_fixed,
            p_leaf_fixed=p_leaf_fixed,
        )


# ---------------------------------------------------------------------------
# Exporter (thin wrapper over io.export_csv and io.project_json)
# ---------------------------------------------------------------------------
class Exporter:
    """Thin wrapper around the IO helpers — what the UI calls."""

    @staticmethod
    def to_elements_dataframe(result: SimulationResult):
        from hydronet.io.export_csv import elements_dataframe
        return elements_dataframe(result)

    @staticmethod
    def to_branches_dataframe(result: SimulationResult):
        from hydronet.io.export_csv import branches_dataframe
        return branches_dataframe(result)

    @staticmethod
    def write_elements_csv(result: SimulationResult, path: str) -> None:
        from hydronet.io.export_csv import write_elements_csv
        write_elements_csv(result, path)

    @staticmethod
    def write_branches_csv(result: SimulationResult, path: str) -> None:
        from hydronet.io.export_csv import write_branches_csv
        write_branches_csv(result, path)

    @staticmethod
    def save_project(network: TreeNetwork, fluid: FluidState,
                     metadata: Optional[dict] = None) -> str:
        from hydronet.io.project_json import save_project
        return save_project(network, fluid, metadata)

    @staticmethod
    def load_project(payload: str) -> tuple[TreeNetwork, FluidState]:
        from hydronet.io.project_json import load_project
        return load_project(payload)


# ---------------------------------------------------------------------------
# Preset demo network
# ---------------------------------------------------------------------------
def build_preset_demo(builder: Optional[NetworkBuilder] = None) -> NetworkBuilder:
    """Build the demo network described in the README/UI.

    Pump → Pipe → Reducer → Pipe → ThrottleValve → Elbow → Pipe → Elbow →
    Pipe → Elbow → Elbow → LEAF (p_fixed = 0).

    Pump curve: dp_rise(Q) = 4e5 − 1e9·Q²  (≈ 4 bar shutoff, drops to 0 near Q=20 L/s).
    """
    if builder is None:
        builder = NetworkBuilder()
    builder.create_new_project("Water", T_C=20.0)
    root = builder.add_node("root", name="ROOT")
    n1 = builder.add_node("junction", name="post_pump")
    n2 = builder.add_node("junction", name="post_p1")
    n3 = builder.add_node("junction", name="post_reducer")
    n4 = builder.add_node("junction", name="post_p2")
    n5 = builder.add_node("junction", name="post_throttle")
    n6 = builder.add_node("junction", name="post_e1")
    n7 = builder.add_node("junction", name="post_p3")
    n8 = builder.add_node("junction", name="post_e2")
    n9 = builder.add_node("junction", name="post_p4")
    n10 = builder.add_node("junction", name="post_e3")
    leaf = builder.add_node("leaf", name="LEAF", p_fixed=0.0)

    D_big = 0.050    # 50 mm
    D_small = 0.032  # 32 mm

    builder.add_pump(
        root.id, n1.id, name="Pump",
        poly_coeffs=[4.0e5, 0.0, -1.0e9],  # 4 bar shutoff, parabolic
    )
    builder.add_pipe(n1.id, n2.id, L_m=2.0, D_m=D_big, material="SteelCommercial",
                     name="P1")
    builder.add_minor_loss(n2.id, n3.id, fitting_type="Reducer", D_ref_m=D_small,
                           name="Reducer")
    builder.add_pipe(n3.id, n4.id, L_m=1.5, D_m=D_small, material="SteelCommercial",
                     name="P2")
    builder.add_minor_loss(n4.id, n5.id, fitting_type="ThrottleValve", D_ref_m=D_small,
                           name="ThrottleValve")
    builder.add_minor_loss(n5.id, n6.id, fitting_type="Elbow90", D_ref_m=D_small,
                           name="E1")
    builder.add_pipe(n6.id, n7.id, L_m=1.0, D_m=D_small, material="SteelCommercial",
                     name="P3")
    builder.add_minor_loss(n7.id, n8.id, fitting_type="Elbow90", D_ref_m=D_small,
                           name="E2")
    builder.add_pipe(n8.id, n9.id, L_m=2.5, D_m=D_small, material="SteelCommercial",
                     name="P4")
    builder.add_minor_loss(n9.id, n10.id, fitting_type="Elbow90", D_ref_m=D_small,
                           name="E3")
    builder.add_minor_loss(n10.id, leaf.id, fitting_type="Elbow90", D_ref_m=D_small,
                           name="E4")
    return builder
