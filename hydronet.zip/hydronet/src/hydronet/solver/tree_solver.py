"""Tree hydraulic solver.

Workflow
--------
1. **Bottom-up reduction** — for every node compute an equivalent
   :class:`HydraulicCurve` representing ``dp_subtree(Q)``. Series children are
   summed; parallel children are combined via :func:`parallel_combine`.
2. **Operating point** — depending on the chosen :class:`SolveMode`, compute
   the total flow ``Q_total`` at the root.
3. **Top-down reconstruction** — walk pre-order distributing flows at every
   junction (each parallel branch sees the same Δp at the junction).
4. **Per-element diagnostics** — call ``compute_diagnostics`` on every element
   and assemble the :class:`SimulationResult`.
"""
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Callable, Optional

from pydantic import BaseModel, Field
from scipy.optimize import brentq

from hydronet.config import (
    DP_ABS_TOL,
    MAX_BRACKET_EXPAND,
    Q_ABS_TOL,
    Q_HI_HINT_INIT,
)
from hydronet.domain.elements.base import Element
from hydronet.domain.elements.pump import PumpElement
from hydronet.domain.fluid import FluidState
from hydronet.domain.network import TreeNetwork
from hydronet.solver.numerics import HydraulicCurve, bracket_and_solve, parallel_combine
from hydronet.utils.logging import get_logger

_logger = get_logger(__name__)


# ---------------------------------------------------------------------------
# Mode + Result models
# ---------------------------------------------------------------------------
class SolveMode(str, Enum):
    A_GIVEN_Q = "A_GIVEN_Q"
    B_GIVEN_DP = "B_GIVEN_DP"
    C_PUMP_OPERATING_POINT = "C_PUMP_OPERATING_POINT"


class SystemResult(BaseModel):
    mode: str
    Q_total: float
    dp_total: float
    convergence_info: dict = Field(default_factory=dict)
    warnings: list[str] = Field(default_factory=list)


class ElementResult(BaseModel):
    element_id: str
    type: str
    Q: float
    dp: float
    v: Optional[float] = None
    Re: Optional[float] = None
    f: Optional[float] = None
    K: Optional[float] = None
    L: Optional[float] = None
    D: Optional[float] = None
    eps: Optional[float] = None
    dp_major: Optional[float] = None
    dp_minor: Optional[float] = None
    dp_rise: Optional[float] = None
    notes: Optional[str] = None


class BranchResult(BaseModel):
    branch_id: str
    Q: float
    dp_total: float
    element_ids: list[str]


class SimulationResult(BaseModel):
    system: SystemResult
    elements: list[ElementResult]
    branches: list[BranchResult]


# ---------------------------------------------------------------------------
# Solver
# ---------------------------------------------------------------------------
@dataclass
class _SubtreeCurves:
    """Container for the curves built during bottom-up reduction."""
    # dp from the to_node of an element through *its* subtree
    subtree_curve: dict[str, HydraulicCurve]
    # dp through (element + subtree below to_node) i.e. the branch as seen
    # from the element's from_node
    branch_curve: dict[str, HydraulicCurve]


class TreeHydraulicSolver:
    """Solve a :class:`TreeNetwork` for flows and pressures."""

    def __init__(self, network: TreeNetwork, fluid: FluidState) -> None:
        network.validate_tree()
        self.network = network
        self.fluid = fluid
        self.warnings: list[str] = []

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------
    def solve_mode_a(self, Q: float) -> SimulationResult:
        """Mode A — total Δp given total Q at root."""
        if Q < 0:
            raise ValueError("Q must be non-negative")
        curves = self._build_subtree_curves(exclude_element=None)
        dp_total = curves.subtree_curve[self.network.root_id].dp(Q)
        flows = self._reconstruct_flows(Q, curves)
        sys_res = SystemResult(
            mode=SolveMode.A_GIVEN_Q.value,
            Q_total=float(Q),
            dp_total=float(dp_total),
            convergence_info={"method": "direct"},
            warnings=list(self.warnings),
        )
        return self._build_simulation_result(sys_res, flows)

    def solve_mode_b(self, dp_target: float) -> SimulationResult:
        """Mode B — total Q at root given target Δp."""
        if dp_target < 0:
            raise ValueError("dp_target must be non-negative")
        curves = self._build_subtree_curves(exclude_element=None)
        root_curve = curves.subtree_curve[self.network.root_id]
        Q = root_curve.inv(dp_target)
        flows = self._reconstruct_flows(Q, curves)
        sys_res = SystemResult(
            mode=SolveMode.B_GIVEN_DP.value,
            Q_total=float(Q),
            dp_total=float(dp_target),
            convergence_info={"method": "brentq+adaptive-bracket"},
            warnings=list(self.warnings),
        )
        return self._build_simulation_result(sys_res, flows)

    def solve_mode_c(
        self,
        pump_element_id: str,
        *,
        p_root_fixed: float = 0.0,
        p_leaf_fixed: float = 0.0,
    ) -> SimulationResult:
        """Mode C — operating point with a pump.

        Solves ``dp_pump(Q) = dp_network_passive(Q) + (p_leaf - p_root)``.

        The pump element is excluded from the passive network curve.  The MVP
        requires the pump to sit at the root (``from_node = root_id``).
        """
        pump = self.network.elements.get(pump_element_id)
        if pump is None:
            raise KeyError(f"Pump element {pump_element_id!r} not found")
        if not isinstance(pump, PumpElement):
            raise TypeError(
                f"Element {pump_element_id!r} is not a PumpElement (it is "
                f"{type(pump).__name__})"
            )
        if pump.from_node != self.network.root_id:
            raise ValueError(
                "MVP: pump must be the first element from the root "
                f"(got from_node={pump.from_node!r}, root={self.network.root_id!r})"
            )

        # Passive network curve as seen at the pump's to_node
        curves = self._build_subtree_curves(exclude_element=pump_element_id)
        passive_curve = curves.subtree_curve[pump.to_node]

        # Operating point: dp_pump(Q) = passive(Q) + dp_boundary
        dp_boundary = float(p_leaf_fixed) - float(p_root_fixed)

        def F(Q: float) -> float:
            return pump.dp_rise(Q, self.fluid) - passive_curve.dp(Q) - dp_boundary

        # F(0) ≈ shutoff head - dp_boundary; with usual decreasing pump curve and
        # increasing network, F is monotonically decreasing, so root sits between 0
        # and Q_max where F goes negative.
        F0 = F(0.0)
        if F0 < -DP_ABS_TOL:
            self.warnings.append(
                f"Mode C: pump shutoff insufficient (F(0)={F0:.3g} Pa). "
                "No positive flow operating point exists."
            )
            Q_op = 0.0
        else:
            Q_hi = max(Q_HI_HINT_INIT, 1e-3)
            for _ in range(MAX_BRACKET_EXPAND):
                if F(Q_hi) < 0.0:
                    break
                Q_hi *= 2.0
            else:  # pragma: no cover - extreme corner
                raise RuntimeError("Mode C: could not bracket the operating point")
            Q_op = float(brentq(F, 0.0, Q_hi, xtol=Q_ABS_TOL))

        # Pump now seen as an element in the tree: contribute negative dp.
        # For reconstruction we still walk the full tree (including the pump).
        full_curves = self._build_subtree_curves(exclude_element=None)
        flows = self._reconstruct_flows(Q_op, full_curves)

        dp_total_full = full_curves.subtree_curve[self.network.root_id].dp(Q_op)
        sys_res = SystemResult(
            mode=SolveMode.C_PUMP_OPERATING_POINT.value,
            Q_total=float(Q_op),
            dp_total=float(dp_total_full),
            convergence_info={
                "method": "brentq",
                "pump_id": pump_element_id,
                "p_root_fixed": float(p_root_fixed),
                "p_leaf_fixed": float(p_leaf_fixed),
                "dp_pump": pump.dp_rise(Q_op, self.fluid),
                "dp_network_passive": passive_curve.dp(Q_op),
            },
            warnings=list(self.warnings),
        )
        return self._build_simulation_result(sys_res, flows)

    # ------------------------------------------------------------------
    # Bottom-up reduction
    # ------------------------------------------------------------------
    def _element_dp_func(self, element: Element) -> Callable[[float], float]:
        f = self.fluid
        return lambda Q, _el=element: _el.dp(Q, f)

    def _build_subtree_curves(self, *, exclude_element: Optional[str]) -> _SubtreeCurves:
        net = self.network
        subtree: dict[str, HydraulicCurve] = {}
        branch: dict[str, HydraulicCurve] = {}

        # Leaves first
        for nid in net.post_order_nodes():
            children = net.children.get(nid, [])
            branch_curves: list[HydraulicCurve] = []
            for eid in children:
                el = net.elements[eid]
                child_node = el.to_node
                child_subtree = subtree[child_node]
                if eid == exclude_element:
                    # Treat the excluded element as transparent (zero dp).
                    el_dp_func: Callable[[float], float] = lambda Q: 0.0
                else:
                    el_dp_func = self._element_dp_func(el)

                def combined(Q: float, _ed=el_dp_func, _cs=child_subtree) -> float:
                    return float(_ed(Q)) + _cs.dp(Q)

                bc = HydraulicCurve(dp_func=combined, label=f"branch[{eid}]")
                branch[eid] = bc
                branch_curves.append(bc)

            if not branch_curves:
                # Leaf node: subtree dp is zero
                subtree[nid] = HydraulicCurve(lambda Q: 0.0, label=f"leaf[{nid}]")
            elif len(branch_curves) == 1:
                subtree[nid] = branch_curves[0]
            else:
                subtree[nid] = parallel_combine(branch_curves)

        return _SubtreeCurves(subtree_curve=subtree, branch_curve=branch)

    # ------------------------------------------------------------------
    # Top-down reconstruction
    # ------------------------------------------------------------------
    def _reconstruct_flows(self, Q_root: float, curves: _SubtreeCurves) -> dict[str, float]:
        """Walk pre-order; return mapping element_id → Q through that element."""
        net = self.network
        flows: dict[str, float] = {}
        # Flow incoming to each node
        node_flow: dict[str, float] = {net.root_id: float(Q_root)}

        for nid in net.pre_order_nodes():
            Q_in = node_flow.get(nid, 0.0)
            children = net.children.get(nid, [])
            if not children:
                continue
            if len(children) == 1:
                eid = children[0]
                flows[eid] = Q_in
                node_flow[net.elements[eid].to_node] = Q_in
            else:
                # Parallel split: all branches share the same dp = dp at node
                # for this Q_in.
                dp_node = curves.subtree_curve[nid].dp(Q_in)
                allocated = 0.0
                last_idx = len(children) - 1
                for idx, eid in enumerate(children):
                    bc = curves.branch_curve[eid]
                    if idx == last_idx:
                        Qi = max(0.0, Q_in - allocated)  # conservation
                    else:
                        Qi = bc.inv(dp_node)
                        allocated += Qi
                    flows[eid] = Qi
                    node_flow[net.elements[eid].to_node] = Qi
        return flows

    # ------------------------------------------------------------------
    # Result assembly
    # ------------------------------------------------------------------
    def _build_simulation_result(self, system: SystemResult,
                                  flows: dict[str, float]) -> SimulationResult:
        elements: list[ElementResult] = []
        for eid, el in self.network.elements.items():
            Q = float(flows.get(eid, 0.0))
            diag = el.compute_diagnostics(Q, self.fluid)
            elements.append(ElementResult(
                element_id=eid,
                type=diag.get("type", el.type_name),
                Q=Q,
                dp=float(diag.get("dp", el.dp(Q, self.fluid))),
                v=diag.get("v"),
                Re=diag.get("Re"),
                f=diag.get("f"),
                K=diag.get("K"),
                L=diag.get("L"),
                D=diag.get("D"),
                eps=diag.get("eps"),
                dp_major=diag.get("dp_major"),
                dp_minor=diag.get("dp_minor"),
                dp_rise=diag.get("dp_rise"),
                notes=diag.get("notes"),
            ))

        branches: list[BranchResult] = []
        for leaf in self.network.leaves():
            path = self.network.path_from_root_to(leaf)
            if not path:
                continue
            Q_branch = float(flows.get(path[-1], 0.0))
            dp_branch = 0.0
            for eid in path:
                Q_el = float(flows.get(eid, 0.0))
                dp_branch += float(self.network.elements[eid].dp(Q_el, self.fluid))
            branches.append(BranchResult(
                branch_id=f"root->{leaf}",
                Q=Q_branch,
                dp_total=dp_branch,
                element_ids=path,
            ))

        return SimulationResult(system=system, elements=elements, branches=branches)
