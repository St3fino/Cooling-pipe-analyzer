"""Build evaluable dp(Q) functions from tabulated data or polynomial coefficients."""
from __future__ import annotations

from typing import Callable, Literal, Optional, Tuple

import numpy as np
from scipy.interpolate import PchipInterpolator

CurveKind = Literal["dp", "pump"]


def _poly_evaluator(coeffs: list[float]) -> Callable[[float], float]:
    """Ascending-order polynomial evaluator: c0 + c1*Q + c2*Q^2 + …"""
    cs = list(coeffs)

    def f(Q: float) -> float:
        Q = max(0.0, float(Q))
        out = 0.0
        p = 1.0
        for c in cs:
            out += c * p
            p *= Q
        return out

    return f


def _table_evaluator(
    Q_arr: np.ndarray,
    dp_arr: np.ndarray,
    *,
    kind: CurveKind,
) -> Tuple[Callable[[float], float], Optional[str]]:
    """Build a monotone-aware interpolator from tabulated data.

    For ``kind='dp'`` (passive), monotone *increasing* dp(Q) is expected.
    For ``kind='pump'`` (active), monotone *decreasing* dp_rise(Q) is expected.
    A piecewise-linear fallback is used otherwise and a warning string is returned.
    """
    order = np.argsort(Q_arr)
    Q_sorted = Q_arr[order]
    dp_sorted = dp_arr[order]

    if Q_sorted.size < 2:
        # Single point → constant function
        const = float(dp_sorted[0]) if dp_sorted.size else 0.0
        return (lambda Q: const), None

    diffs = np.diff(dp_sorted)
    monotone_up = bool(np.all(diffs >= -1e-12))
    monotone_down = bool(np.all(diffs <= 1e-12))
    warning: Optional[str] = None
    use_pchip = (kind == "dp" and monotone_up) or (kind == "pump" and monotone_down)

    if use_pchip:
        try:
            pchip = PchipInterpolator(Q_sorted, dp_sorted, extrapolate=True)

            def f(Q: float) -> float:
                Q = max(0.0, float(Q))
                if Q <= Q_sorted[0]:
                    # Linear extrapolation toward 0 for stability at Q=0
                    if Q_sorted[0] > 0.0:
                        slope = (dp_sorted[1] - dp_sorted[0]) / (Q_sorted[1] - Q_sorted[0])
                        return float(dp_sorted[0] - slope * (Q_sorted[0] - Q))
                    return float(dp_sorted[0])
                if Q >= Q_sorted[-1]:
                    slope = (dp_sorted[-1] - dp_sorted[-2]) / (Q_sorted[-1] - Q_sorted[-2])
                    return float(dp_sorted[-1] + slope * (Q - Q_sorted[-1]))
                return float(pchip(Q))

            return f, None
        except Exception as exc:  # pragma: no cover - fallback path
            warning = f"PCHIP build failed ({exc}); using linear interpolation."
    else:
        warning = (f"Tabulated curve is not monotone "
                   f"{'increasing' if kind == 'dp' else 'decreasing'}; "
                   "using piecewise-linear interpolation.")

    # Linear fallback with extrapolation
    def linf(Q: float) -> float:
        Q = max(0.0, float(Q))
        return float(np.interp(Q, Q_sorted, dp_sorted,
                               left=dp_sorted[0], right=dp_sorted[-1]))

    return linf, warning


def build_dp_curve(
    *,
    Q_points: Optional[list[float]] = None,
    dp_points: Optional[list[float]] = None,
    poly_coeffs: Optional[list[float]] = None,
    kind: CurveKind = "dp",
) -> Tuple[Callable[[float], float], Optional[str]]:
    """Return a callable dp(Q) (or dp_rise(Q) for pumps) and an optional warning.

    Raises ``ValueError`` if neither a table nor coefficients are provided.
    """
    if poly_coeffs is not None:
        return _poly_evaluator(poly_coeffs), None
    if Q_points is not None and dp_points is not None:
        Q_arr = np.asarray(Q_points, dtype=float)
        dp_arr = np.asarray(dp_points, dtype=float)
        if Q_arr.shape != dp_arr.shape:
            raise ValueError("Q_points and dp_points must have the same length")
        if Q_arr.size == 0:
            raise ValueError("Empty curve data")
        if np.any(Q_arr < 0):
            raise ValueError("Q_points must be non-negative")
        return _table_evaluator(Q_arr, dp_arr, kind=kind)
    raise ValueError("Provide either (Q_points, dp_points) or poly_coeffs")
