"""Numerical primitives used by the tree solver.

The central abstraction is :class:`HydraulicCurve` which wraps any
``dp(Q)`` function and provides a robust inverse via adaptive bracketing
plus Brent root-finding.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, Iterable

from scipy.optimize import brentq

from hydronet.config import (
    DP_ABS_TOL,
    MAX_BRACKET_EXPAND,
    Q_ABS_TOL,
    Q_HI_HINT_INIT,
)


def bracket_and_solve(
    f: Callable[[float], float],
    *,
    x_lo: float = 0.0,
    x_hi_hint: float = Q_HI_HINT_INIT,
    max_expand: int = MAX_BRACKET_EXPAND,
    xtol: float = Q_ABS_TOL,
) -> float:
    """Find a root of ``f`` on ``[x_lo, x_hi]`` expanding the upper bound as needed.

    ``f(x_lo)`` must be ≤ 0 and we keep doubling ``x_hi`` until ``f(x_hi)`` > 0.
    Raises :class:`RuntimeError` if no bracket can be found.
    """
    f_lo = f(x_lo)
    if abs(f_lo) <= xtol:
        return x_lo
    if f_lo > 0.0:
        # Already past the root from below; common when target ≤ 0.
        return x_lo
    x_hi = max(x_hi_hint, x_lo + 1e-9)
    for _ in range(max_expand):
        if f(x_hi) > 0.0:
            return float(brentq(f, x_lo, x_hi, xtol=xtol))
        x_hi *= 2.0
    raise RuntimeError(
        f"bracket_and_solve: could not bracket a sign change after {max_expand} expansions "
        f"(last x_hi={x_hi:g})"
    )


# ---------------------------------------------------------------------------
# HydraulicCurve
# ---------------------------------------------------------------------------
@dataclass
class HydraulicCurve:
    """Lazy wrapper around ``dp(Q)`` with adaptive inverse.

    ``dp_func`` must be a callable returning Pa for any non-negative Q in
    m^3/s, monotonically non-decreasing on the relevant range.
    """

    dp_func: Callable[[float], float]
    label: str = ""
    q_hi_seed: float = Q_HI_HINT_INIT

    def dp(self, Q: float) -> float:
        if Q <= 0.0:
            return float(self.dp_func(0.0))
        return float(self.dp_func(float(Q)))

    def inv(self, dp_target: float, *, q_hi_hint: float | None = None) -> float:
        """Solve dp(Q) = dp_target for Q ≥ 0."""
        if dp_target <= DP_ABS_TOL:
            return 0.0
        hint = q_hi_hint if q_hi_hint is not None else self.q_hi_seed
        Q = bracket_and_solve(
            lambda q: self.dp(q) - dp_target,
            x_lo=0.0,
            x_hi_hint=hint,
            xtol=Q_ABS_TOL,
        )
        # Speed up future calls in similar pressure range.
        self.q_hi_seed = max(self.q_hi_seed, Q * 2.0)
        return Q


# ---------------------------------------------------------------------------
# Parallel branch combination
# ---------------------------------------------------------------------------
def parallel_combine(branch_curves: Iterable[HydraulicCurve]) -> HydraulicCurve:
    """Combine parallel branches into a single equivalent curve.

    Each branch shares the same upstream node so they all see the same
    ``dp`` at their inlet (their respective leaf pressures are assumed equal
    for the MVP). The total flow at the junction is
    ``Q_total(dp) = Σ inv_i(dp)``. We invert that mapping to get ``dp(Q_total)``.
    """
    branches = list(branch_curves)
    if not branches:
        raise ValueError("parallel_combine requires at least one branch")
    if len(branches) == 1:
        return branches[0]

    def total_Q_at(dp: float) -> float:
        return sum(bc.inv(dp) for bc in branches)

    def dp_node(Q_total: float) -> float:
        if Q_total <= 0.0:
            return 0.0
        # Bracket dp:  at dp=0 → total_Q=0; expand until total_Q ≥ Q_total.
        dp_hi = max(bc.dp(Q_total) for bc in branches)
        dp_hi = max(dp_hi, 1.0)
        for _ in range(MAX_BRACKET_EXPAND):
            if total_Q_at(dp_hi) >= Q_total:
                break
            dp_hi *= 2.0
        else:  # pragma: no cover - extreme corner
            raise RuntimeError("parallel_combine: cannot bracket dp for given Q_total")
        return float(brentq(lambda d: total_Q_at(d) - Q_total, 0.0, dp_hi, xtol=DP_ABS_TOL))

    return HydraulicCurve(dp_func=dp_node, label="parallel(" +
                          ",".join(bc.label for bc in branches) + ")")
