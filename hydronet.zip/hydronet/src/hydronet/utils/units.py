"""Small unit conversion helpers used across the package and UI."""
from __future__ import annotations


def c_to_k(t_c: float) -> float:
    """Celsius to Kelvin."""
    return t_c + 273.15


def k_to_c(t_k: float) -> float:
    """Kelvin to Celsius."""
    return t_k - 273.15


def lpm_to_m3s(q_lpm: float) -> float:
    """Litres per minute to cubic metres per second."""
    return q_lpm / 60000.0


def m3s_to_lpm(q_m3s: float) -> float:
    """Cubic metres per second to litres per minute."""
    return q_m3s * 60000.0


def bar_to_pa(p_bar: float) -> float:
    """Bar to Pascal."""
    return p_bar * 1.0e5


def pa_to_bar(p_pa: float) -> float:
    """Pascal to bar."""
    return p_pa / 1.0e5


def mm_to_m(length_mm: float) -> float:
    """Millimetres to metres."""
    return length_mm / 1000.0
