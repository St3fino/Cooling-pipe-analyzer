"""Simple logging configuration helper."""
from __future__ import annotations

import logging
import sys

_DEFAULT_FMT = "%(asctime)s [%(name)s] %(levelname)s %(message)s"


def setup_logging(level: int | str = logging.INFO, *, fmt: str = _DEFAULT_FMT) -> None:
    """Configure the root logger once with a basic console handler.

    Safe to call repeatedly — adds a handler only if the root logger has none.
    """
    root = logging.getLogger()
    if root.handlers:
        root.setLevel(level)
        return
    handler = logging.StreamHandler(stream=sys.stderr)
    handler.setFormatter(logging.Formatter(fmt))
    root.addHandler(handler)
    root.setLevel(level)


def get_logger(name: str) -> logging.Logger:
    """Convenience wrapper returning a named logger."""
    return logging.getLogger(name)
