"""Parallel-split test.

Tree::

           root ── e0:pipe1 ── J ──┬── e1:pipe2 ── leaf1 (p_fixed = 0)
                                   └── e2:pipe3 ── leaf2 (p_fixed = 0)

With equal leaf pressures, the solver must:

* conserve mass: Q1 + Q2 ≈ Q_total
* equalise dp across the parallel branches at junction J
"""
from __future__ import annotations

import pytest

from hydronet.app.use_cases import NetworkBuilder, ScenarioRunner


@pytest.fixture
def split_network():
    b = NetworkBuilder()
    b.create_new_project("Water", T_C=20.0)
    root = b.add_node("root", name="root")
    junction = b.add_node("junction", name="J")
    leaf1 = b.add_node("leaf", name="leaf1", p_fixed=0.0)
    leaf2 = b.add_node("leaf", name="leaf2", p_fixed=0.0)

    e0 = b.add_pipe(root.id, junction.id,
                    L_m=1.0, D_m=0.040, material="SteelCommercial",
                    name="trunk")
    # Two branches with different diameters so flow split is non-trivial
    e1 = b.add_pipe(junction.id, leaf1.id,
                    L_m=2.0, D_m=0.030, material="SteelCommercial",
                    name="branch_A")
    e2 = b.add_pipe(junction.id, leaf2.id,
                    L_m=2.0, D_m=0.020, material="SteelCommercial",
                    name="branch_B")
    network = b.finalize()
    return network, b.fluid_state, (e0.id, e1.id, e2.id)


def test_mass_conservation_at_split(split_network):
    network, fluid, (trunk_id, a_id, b_id) = split_network
    Q_total = 1.5e-3   # 1.5 L/s
    result = ScenarioRunner.run_mode_a(network, fluid, Q=Q_total)
    by_id = {er.element_id: er for er in result.elements}

    assert by_id[trunk_id].Q == pytest.approx(Q_total, rel=1e-9)
    Q_a = by_id[a_id].Q
    Q_b = by_id[b_id].Q
    assert Q_a + Q_b == pytest.approx(Q_total, rel=1e-6)
    # Larger branch should carry more flow
    assert Q_a > Q_b


def test_equal_dp_across_parallel_branches(split_network):
    network, fluid, (trunk_id, a_id, b_id) = split_network
    Q_total = 1.5e-3
    result = ScenarioRunner.run_mode_a(network, fluid, Q=Q_total)
    by_id = {er.element_id: er for er in result.elements}

    # Each branch contains a single pipe → the per-element dp IS the branch dp
    dp_a = by_id[a_id].dp
    dp_b = by_id[b_id].dp
    assert dp_a == pytest.approx(dp_b, rel=1e-4), (
        f"parallel branches must drop equal pressure, got "
        f"{dp_a:.4f} Pa vs {dp_b:.4f} Pa"
    )


def test_total_dp_is_trunk_plus_branch(split_network):
    network, fluid, (trunk_id, a_id, b_id) = split_network
    Q_total = 1.5e-3
    result = ScenarioRunner.run_mode_a(network, fluid, Q=Q_total)
    by_id = {er.element_id: er for er in result.elements}

    expected = by_id[trunk_id].dp + by_id[a_id].dp
    assert result.system.dp_total == pytest.approx(expected, rel=1e-6)
