"""Sanity checks for :class:`PipeElement`.

The pipe drop should be positive for any positive flow, and in the turbulent
regime (high Re) it should scale approximately like Q² because Darcy-Weisbach
is dp = f·(L/D)·(ρ·v²/2) with f only weakly Re-dependent.
"""
from __future__ import annotations

import math

import pytest

from hydronet.domain.elements.pipe import PipeElement
from hydronet.domain.fluid import get_fluid_state
from hydronet.utils.units import c_to_k


@pytest.fixture
def water_20C():
    return get_fluid_state("Water", c_to_k(20.0))


@pytest.fixture
def pipe():
    return PipeElement(
        id="p1", name="pipe", from_node="a", to_node="b",
        L_m=2.0, D_m=0.025, material="SteelCommercial",
    )


def test_dp_is_zero_at_zero_flow(pipe, water_20C):
    assert pipe.dp(0.0, water_20C) == pytest.approx(0.0, abs=1e-9)


def test_dp_is_positive_for_positive_flow(pipe, water_20C):
    # 5 L/min through a 25 mm pipe → clearly turbulent
    Q = 5.0 / 60000.0
    assert pipe.dp(Q, water_20C) > 0.0


def test_dp_scales_approximately_quadratically_in_turbulent_regime(
    pipe, water_20C
):
    # Pick two flow rates that both sit well in the fully-rough turbulent
    # regime so the friction factor barely changes between them.
    Q1 = 1.0e-3      # 1 L/s  → Re ~ 5e4
    Q2 = 2.0 * Q1    # 2 L/s  → Re ~ 1e5

    # Sanity: confirm we are really turbulent at the lower flow
    d1 = pipe.compute_diagnostics(Q1, water_20C)
    assert d1["Re"] > 1.0e4, f"expected turbulent flow, got Re={d1['Re']:.1f}"

    dp1 = pipe.dp(Q1, water_20C)
    dp2 = pipe.dp(Q2, water_20C)
    ratio = dp2 / dp1

    # Pure Q² would give 4.0; f decreases slightly with Re so allow a band.
    assert 3.6 < ratio < 4.2, f"dp(2Q)/dp(Q) = {ratio:.3f} (expected ≈ 4)"


def test_diagnostics_are_self_consistent(pipe, water_20C):
    Q = 2.0e-3
    d = pipe.compute_diagnostics(Q, water_20C)
    A = math.pi * (pipe.D_m ** 2) / 4.0
    v_expected = Q / A
    assert d["v"] == pytest.approx(v_expected, rel=1e-12)
    Re_expected = water_20C.rho * v_expected * pipe.D_m / water_20C.mu
    assert d["Re"] == pytest.approx(Re_expected, rel=1e-12)
    dp_expected = d["f"] * (pipe.L_m / pipe.D_m) * (
        water_20C.rho * v_expected ** 2 / 2.0
    )
    assert d["dp_major"] == pytest.approx(dp_expected, rel=1e-10)
