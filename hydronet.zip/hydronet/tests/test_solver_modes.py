"""Tests for the three solver modes.

* **Mode A**: given Q, compute Δp.
* **Mode B**: given Δp, recover Q. Must be the inverse of Mode A within
  tolerance.
* **Mode C**: pump operating point. With a pump curve
  ``dp_rise(Q) = dp0 − k·Q²`` feeding a quadratic resistor
  ``dp = c·Q²``, the analytical solution is ``Q* = sqrt(dp0 / (k + c))``.
"""
from __future__ import annotations

import math

import pytest

from hydronet.app.use_cases import NetworkBuilder, ScenarioRunner


# ---------------------------------------------------------------------------
# Mode A / Mode B — round trip
# ---------------------------------------------------------------------------
@pytest.fixture
def simple_pipe_network():
    b = NetworkBuilder()
    b.create_new_project("Water", T_C=20.0)
    root = b.add_node("root", name="root")
    leaf = b.add_node("leaf", name="leaf", p_fixed=0.0)
    b.add_pipe(root.id, leaf.id,
               L_m=5.0, D_m=0.025, material="SteelCommercial", name="pipe")
    return b.finalize(), b.fluid_state


def test_mode_a_returns_positive_dp(simple_pipe_network):
    net, fluid = simple_pipe_network
    Q = 1.0e-3
    result = ScenarioRunner.run_mode_a(net, fluid, Q=Q)
    assert result.system.Q_total == pytest.approx(Q, rel=1e-12)
    assert result.system.dp_total > 0.0


def test_mode_b_is_inverse_of_mode_a(simple_pipe_network):
    net, fluid = simple_pipe_network
    Q = 1.5e-3
    r_a = ScenarioRunner.run_mode_a(net, fluid, Q=Q)
    dp_target = r_a.system.dp_total

    r_b = ScenarioRunner.run_mode_b(net, fluid, dp_target=dp_target)
    assert r_b.system.Q_total == pytest.approx(Q, rel=1e-4)
    assert r_b.system.dp_total == pytest.approx(dp_target, rel=1e-4)


# ---------------------------------------------------------------------------
# Mode C — pump intersection with quadratic resistor (analytical)
# ---------------------------------------------------------------------------
def test_mode_c_finds_analytical_operating_point():
    """Build a network with one polynomial pump and one polynomial resistor
    that both follow exact quadratic laws.

    Pump:     dp_rise(Q) = dp0 − k·Q²      (poly coeffs [dp0, 0, -k])
    Resistor: dp(Q)      = c·Q²            (poly coeffs [0, 0,  c])

    The operating point ``dp_pump = dp_network`` resolves analytically to
    ``Q* = sqrt(dp0 / (k + c))``.
    """
    dp0 = 4.0e5     # 4 bar shutoff
    k = 1.0e9
    c = 3.0e9
    Q_star = math.sqrt(dp0 / (k + c))
    dp_star = c * Q_star ** 2

    b = NetworkBuilder()
    b.create_new_project("Water", T_C=20.0)
    root = b.add_node("root", name="root")
    n1 = b.add_node("junction", name="post_pump")
    leaf = b.add_node("leaf", name="leaf", p_fixed=0.0)

    pump = b.add_pump(root.id, n1.id, poly_coeffs=[dp0, 0.0, -k],
                      name="pump")
    b.add_curve_component(n1.id, leaf.id, poly_coeffs=[0.0, 0.0, c],
                          name="resistor")

    network = b.finalize()
    result = ScenarioRunner.run_mode_c(network, b.fluid_state,
                                       pump_element_id=pump.id)

    assert result.system.Q_total == pytest.approx(Q_star, rel=5e-4), (
        f"expected Q*={Q_star:.6e}, got {result.system.Q_total:.6e}"
    )
    assert result.system.dp_total == pytest.approx(dp_star, rel=5e-4)


def test_mode_c_with_leaf_back_pressure_shifts_operating_point():
    """Adding a leaf back-pressure should reduce the flow because the pump
    now has to overcome an additional constant Δp."""
    dp0 = 4.0e5
    k = 1.0e9
    c = 3.0e9
    p_leaf = 5.0e4   # 0.5 bar leaf back-pressure

    b = NetworkBuilder()
    b.create_new_project("Water", T_C=20.0)
    root = b.add_node("root", name="root")
    n1 = b.add_node("junction", name="post_pump")
    leaf = b.add_node("leaf", name="leaf", p_fixed=p_leaf)

    pump = b.add_pump(root.id, n1.id, poly_coeffs=[dp0, 0.0, -k])
    b.add_curve_component(n1.id, leaf.id, poly_coeffs=[0.0, 0.0, c])

    network = b.finalize()
    result = ScenarioRunner.run_mode_c(network, b.fluid_state,
                                       pump_element_id=pump.id,
                                       p_leaf_fixed=p_leaf)

    # Analytical: dp0 − k·Q² = c·Q² + p_leaf  →  Q = sqrt((dp0 - p_leaf)/(k+c))
    Q_expected = math.sqrt((dp0 - p_leaf) / (k + c))
    Q_baseline = math.sqrt(dp0 / (k + c))

    assert result.system.Q_total == pytest.approx(Q_expected, rel=5e-4)
    assert result.system.Q_total < Q_baseline   # back-pressure reduces flow
